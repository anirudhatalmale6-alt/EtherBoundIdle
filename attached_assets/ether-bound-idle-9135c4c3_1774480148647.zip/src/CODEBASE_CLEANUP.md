# 🧹 COMPLETE CODEBASE CLEANUP PLAN

## ✅ PERSISTENCE SYSTEMS IMPLEMENTED

1. **PlayerSession Entity** - Central session tracking
2. **processServerProgression.js** - Server-side progression with offline calculations
3. **enforceGameLimits.js** - Server-side limit enforcement (guild boss, dungeons)
4. **manageGuildApplication.js** - Private guild application system

---

## 🗑️ DUPLICATE/DEPRECATED SYSTEMS TO REMOVE

### Backend Functions (Remove These - Consolidated to processServerProgression.js)
- `manageCombatSession.js` → ❌ Use processServerProgression (save_combat, clear_combat)
- `catchUpOfflineProgress.js` → ❌ Logic moved to processServerProgression (sync_progression)
- `processOfflineProgressionTick.js` → ❌ Consolidated to processServerProgression
- `processGemLab.js` → ❌ Gem generation now in processServerProgression
- `lifeSkills.js` → ⚠️ KEEP but integrate with processServerProgression for offline sync

### Frontend State Management to Remove
- Local storage timers for life skills (e.g., `sessionStartTime` in LifeSkills)
- Client-side combat timers that reset on tab switch
- Any `setTimeout` for progression (must be server-driven)
- Client-side "offline duration" calculations

### Component Logic to Refactor
- **Battle.jsx**: Remove local enemy spawn logic, use restored state from PlayerSession
- **LifeSkills.jsx**: Remove local tick timers, rely on server progression sync
- **GemLabPanel.jsx**: Remove local gem calculations, use GemLab entity + processServerProgression
- **Dungeons.jsx**: Add `enforceGameLimits` check before entry
- **GuildPage.jsx**: Remove direct member management, use `manageGuildApplication` for private guilds

---

## 🔄 FRONTEND-BACKEND SYNC FLOW

### On App Load
1. User authenticates
2. Character loads
3. Call `processServerProgression.sync_progression()` → Returns: exp gained, resources, gems, offline duration
4. Apply rewards to character display
5. Check if combat exists: restore from PlayerSession.combat_state
6. Display current state to user

### During Active Play
- Battle: Every 60s, save combat state via `processServerProgression.save_combat`
- LifeSkills: Every 30s, sync skill progress via server
- Before Tab Close: `beforeunload` event → save all active state

### On Idle Progression
- Server-side automations run every 5 minutes
- Calculate: offline_duration since last_sync
- Apply: XP, resources, gems to character/inventory

---

## 📋 CRITICAL RULES

### NEVER
- ❌ Store progression state in localStorage
- ❌ Use client-side timers for resource gathering
- ❌ Calculate offline rewards on frontend
- ❌ Allow multiple simultaneous skill activities
- ❌ Display data without server verification

### ALWAYS
- ✅ Call processServerProgression to start/stop skills
- ✅ Save combat before leaving tab
- ✅ Verify limits server-side (enforceGameLimits)
- ✅ Sync progression every 60 seconds
- ✅ Display only what server returns

---

## 🧯 SPECIFIC REMOVALS

### In `pages/Battle.jsx`
```javascript
// ❌ REMOVE: Client-side offline catch-up
useEffect(() => {
  if (!character?.id || offlineProcessedRef.current) return;
  offlineProcessedRef.current = true;
  const run = async () => {
    const response = await base44.functions.invoke('catchUpOfflineProgress', ...);
    // ...
  };
}, [character?.id]);

// ✅ REPLACE with: processServerProgression sync on mount
```

### In `pages/LifeSkills.jsx`
```javascript
// ❌ REMOVE: Local tick timers and sessionStartTime
const [sessionStartTime, setSessionStartTime] = useState(null);

// ❌ REMOVE: Client-side tick interval
useEffect(() => {
  if (!activeSkillType || !sessionStartTime) return;
  const interval = setInterval(() => {
    // Manual tick calculation
  }, 5000);
}, [activeSkillType, sessionStartTime]);

// ✅ Already using server-side lifeSkills function ✓
```

### In `components/game/GemLabPanel.jsx`
```javascript
// ❌ REMOVE: Local gem calculation with Date.now()
const secondsElapsed = (Date.now() - (lastCollectionTime ? new Date(lastCollectionTime).getTime() : Date.now())) / 1000;
const gemsGenerated = Math.floor(baseRate * (secondsElapsed / 60));

// ✅ REPLACE with: GemLab entity + server-side calculations
```

### In `pages/Dungeons.jsx`
```javascript
// ❌ ADD CHECK before entering dungeon:
const response = await base44.functions.invoke('enforceGameLimits', {
  characterId: character.id,
  limitType: 'dungeon',
  gemCost: 25, // Cost for extra entries beyond free 2
});

if (!response.data?.success) {
  toast({ title: response.data?.error || 'Entry limit reached' });
  return;
}
```

### In `pages/GuildPage.jsx`
```javascript
// ❌ REMOVE: Direct member array manipulation
// ✅ ADD: manageGuildApplication function for private guilds

// For private guild join:
const response = await base44.functions.invoke('manageGuildApplication', {
  action: 'apply',
  guildId: guild.id,
  characterId: character.id,
});
```

---

## 🎯 FINAL VERIFICATION CHECKLIST

- [ ] All character progression is server-driven
- [ ] No localStorage used for game state
- [ ] Combat persists across tab switches
- [ ] Life skills continue offline
- [ ] Gem Lab generates gems without player action
- [ ] Guild boss limited to 3 free, 5 with gems per day
- [ ] Dungeon limited to 2 free, 4 with gems per day
- [ ] Private guilds require application + approval
- [ ] All limits are server-enforced
- [ ] No client-side timers for progression
- [ ] Every 60s sync with server
- [ ] Tab close saves all state

---

## 🔗 INTEGRATION POINTS

**Automations needed** (create in Base44 dashboard):
1. `processServerProgression` → Scheduled every 5 minutes (for idle offline players)
2. Daily reset check → Scheduled at midnight for limits reset

**Frontend calls to create**:
1. Load character → call `sync_progression` → display results
2. Start skill → call `start_skill`
3. Stop skill → call `stop_skill`
4. Every 60s active → call `sync_progression`
5. Before unload → call `save_combat` (for battle)
6. Join dungeon → call `enforceGameLimits`
7. Summon guild boss → call `enforceGameLimits`
8. Apply to guild → call `manageGuildApplication` (apply)