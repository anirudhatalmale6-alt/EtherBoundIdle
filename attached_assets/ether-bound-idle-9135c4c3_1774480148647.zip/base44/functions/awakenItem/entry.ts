import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { itemId } = await req.json();

    // Fetch item and character
    const item = await base44.entities.Item.filter({ id: itemId }).then(items => items[0]);
    const character = await base44.entities.Character.filter({
      created_by: user.email
    }).then(chars => chars[0]);

    if (!item || !character) {
      return Response.json({ error: 'Item or character not found' }, { status: 404 });
    }

    // Requirements
    if ((item.star_level || 0) < 7) {
      return Response.json({
        error: 'Item must be at star level 7 to awaken',
        currentStar: item.star_level || 0
      }, { status: 400 });
    }

    if (item.is_awakened) {
      return Response.json({ error: 'Item already awakened' }, { status: 400 });
    }

    // Cost: 50 gems for awakening (prestigious endgame cost)
    const awakeCost = 50;

    if ((character.gems || 0) < awakeCost) {
      return Response.json({
        error: 'Not enough gems for awakening',
        required: awakeCost,
        current: character.gems || 0
      }, { status: 400 });
    }

    // Deduct gems
    await base44.entities.Character.update(character.id, {
      gems: character.gems - awakeCost
    });

    // Apply awakening: +50% bonus to all stats
    const awakenBonus = 1.5;
    const awakenedStats = {};
    for (const [stat, value] of Object.entries(item.stats || {})) {
      awakenedStats[stat] = Math.round(value * awakenBonus);
    }

    const updated = await base44.entities.Item.update(item.id, {
      is_awakened: true,
      stats: awakenedStats
    });

    return Response.json({
      success: true,
      itemName: item.name,
      gemsSpent: awakeCost,
      message: `✨ LEGENDARY! ${item.name} has been AWAKENED! All stats increased by 50%! ✨`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});