import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * Enforce server-side game limits that cannot be bypassed by client
 * - Guild boss summons (3 free per day, 5 with gems)
 * - Dungeon entries (2 free per day, 4 with gems)
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { characterId, limitType, gemCost } = body;

    if (!characterId || !limitType) {
      return Response.json({ error: 'Missing parameters' }, { status: 400 });
    }

    // Verify character ownership
    const char = await base44.asServiceRole.entities.Character.filter({ 
      id: characterId, 
      created_by: user.email 
    });
    if (!char[0]) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    const character = char[0];
    const now = new Date();

    // Get or create session
    const sessions = await base44.asServiceRole.entities.PlayerSession.filter({ 
      character_id: characterId 
    });
    let session = sessions[0];

    if (!session) {
      session = await base44.asServiceRole.entities.PlayerSession.create({
        character_id: characterId,
        last_active: now.toISOString(),
        last_sync: now.toISOString(),
        daily_limits: {
          guild_boss_uses: 0,
          dungeon_entries: 0,
          last_limit_reset: now.toISOString(),
        },
      });
    }

    // Check if daily limit needs reset
    const lastReset = new Date(session.daily_limits?.last_limit_reset || now);
    const daysSinceReset = Math.floor((now - lastReset) / (24 * 60 * 60000));

    let limits = session.daily_limits || {};
    if (daysSinceReset >= 1) {
      limits = {
        guild_boss_uses: 0,
        dungeon_entries: 0,
        last_limit_reset: now.toISOString(),
      };
    }

    // GUILD BOSS LIMIT
    if (limitType === 'guild_boss') {
      const maxFree = 3;
      const maxWithGems = 5;
      const currentUses = limits.guild_boss_uses || 0;

      // Check if at free limit
      if (currentUses >= maxFree) {
        // Need gems for additional summons
        if (currentUses >= maxWithGems) {
          return Response.json(
            { error: 'Daily limit reached (5 max with gems)', code: 'LIMIT_EXCEEDED' },
            { status: 403 }
          );
        }

        // Charge gems
        if (character.gems < gemCost) {
          return Response.json(
            { error: `Insufficient gems. Need ${gemCost}, have ${character.gems}`, code: 'INSUFFICIENT_GEMS' },
            { status: 402 }
          );
        }

        // Deduct gems
        await base44.asServiceRole.entities.Character.update(character.id, {
          gems: character.gems - gemCost,
        });
      }

      // Increment counter
      limits.guild_boss_uses = (currentUses || 0) + 1;
    }

    // DUNGEON ENTRY LIMIT
    if (limitType === 'dungeon') {
      const maxFree = 2;
      const maxWithGems = 4;
      const currentEntries = limits.dungeon_entries || 0;

      // Check if at free limit
      if (currentEntries >= maxFree) {
        // Need gems for additional entries
        if (currentEntries >= maxWithGems) {
          return Response.json(
            { error: 'Daily limit reached (4 max with gems)', code: 'LIMIT_EXCEEDED' },
            { status: 403 }
          );
        }

        // Charge gems
        if (character.gems < gemCost) {
          return Response.json(
            { error: `Insufficient gems. Need ${gemCost}, have ${character.gems}`, code: 'INSUFFICIENT_GEMS' },
            { status: 402 }
          );
        }

        // Deduct gems
        await base44.asServiceRole.entities.Character.update(character.id, {
          gems: character.gems - gemCost,
        });
      }

      // Increment counter
      limits.dungeon_entries = (currentEntries || 0) + 1;
    }

    // Update session with new limits
    await base44.asServiceRole.entities.PlayerSession.update(session.id, {
      daily_limits: limits,
      last_active: now.toISOString(),
    });

    return Response.json({
      success: true,
      remaining: limitType === 'guild_boss' 
        ? Math.max(0, (limitType === 'guild_boss' ? 5 : 4) - limits[limitType === 'guild_boss' ? 'guild_boss_uses' : 'dungeon_entries'])
        : Math.max(0, (limitType === 'guild_boss' ? 5 : 4) - limits[limitType === 'guild_boss' ? 'guild_boss_uses' : 'dungeon_entries']),
      cost_gems: limits[limitType === 'guild_boss' ? 'guild_boss_uses' : 'dungeon_entries'] > (limitType === 'guild_boss' ? 3 : 2) ? gemCost : 0,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});