import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * Handle guild application and approval system for private guilds
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { action, guildId, characterId } = body;

    if (!action || !guildId) {
      return Response.json({ error: 'Missing parameters' }, { status: 400 });
    }

    // Verify guild exists
    const guilds = await base44.asServiceRole.entities.Guild.filter({ id: guildId });
    if (!guilds[0]) {
      return Response.json({ error: 'Guild not found' }, { status: 404 });
    }

    const guild = guilds[0];

    // ACTION: apply
    if (action === 'apply') {
      if (!characterId) {
        return Response.json({ error: 'Missing characterId' }, { status: 400 });
      }

      // Check if guild is private
      if (guild.is_public) {
        return Response.json({ error: 'Guild is public - join directly' }, { status: 400 });
      }

      // Verify character ownership
      const chars = await base44.asServiceRole.entities.Character.filter({ 
        id: characterId, 
        created_by: user.email 
      });
      if (!chars[0]) {
        return Response.json({ error: 'Character not found' }, { status: 404 });
      }

      const character = chars[0];

      // Check if already applied
      const existing = await base44.asServiceRole.entities.GuildApplication.filter({
        guild_id: guildId,
        character_id: characterId,
        status: 'pending',
      });

      if (existing[0]) {
        return Response.json({ error: 'Already applied to this guild' }, { status: 400 });
      }

      // Create application
      const app = await base44.asServiceRole.entities.GuildApplication.create({
        guild_id: guildId,
        character_id: characterId,
        character_name: character.name,
        status: 'pending',
        applied_at: new Date().toISOString(),
      });

      return Response.json({ success: true, message: 'Application submitted', applicationId: app.id });
    }

    // ACTION: accept
    if (action === 'accept') {
      const { applicationId } = body;
      if (!applicationId) {
        return Response.json({ error: 'Missing applicationId' }, { status: 400 });
      }

      // Verify guild leader
      if (guild.leader_id !== characterId) {
        return Response.json({ error: 'Only guild leader can approve' }, { status: 403 });
      }

      // Get application
      const apps = await base44.asServiceRole.entities.GuildApplication.filter({ id: applicationId });
      if (!apps[0]) {
        return Response.json({ error: 'Application not found' }, { status: 404 });
      }

      const app = apps[0];

      // Update application
      await base44.asServiceRole.entities.GuildApplication.update(app.id, {
        status: 'accepted',
        decided_at: new Date().toISOString(),
        decided_by: characterId,
      });

      // Add to guild (via manageParty logic or here)
      // This assumes the guild system uses a similar member structure
      const member = {
        character_id: app.character_id,
        name: app.character_name,
        role: 'member',
        joined_at: new Date().toISOString(),
        boss_damage_today: 0,
      };

      const updatedMembers = [...(guild.members || []), member];
      await base44.asServiceRole.entities.Guild.update(guild.id, {
        members: updatedMembers,
        member_count: updatedMembers.length,
      });

      return Response.json({ success: true, message: 'Application accepted' });
    }

    // ACTION: reject
    if (action === 'reject') {
      const { applicationId } = body;
      if (!applicationId) {
        return Response.json({ error: 'Missing applicationId' }, { status: 400 });
      }

      // Verify guild leader
      if (guild.leader_id !== characterId) {
        return Response.json({ error: 'Only guild leader can reject' }, { status: 403 });
      }

      // Get application
      const apps = await base44.asServiceRole.entities.GuildApplication.filter({ id: applicationId });
      if (!apps[0]) {
        return Response.json({ error: 'Application not found' }, { status: 404 });
      }

      const app = apps[0];

      // Update application
      await base44.asServiceRole.entities.GuildApplication.update(app.id, {
        status: 'rejected',
        decided_at: new Date().toISOString(),
        decided_by: characterId,
      });

      return Response.json({ success: true, message: 'Application rejected' });
    }

    // ACTION: list_pending (for guild leader)
    if (action === 'list_pending') {
      // Verify guild leader
      if (guild.leader_id !== characterId) {
        return Response.json({ error: 'Only guild leader can view applications' }, { status: 403 });
      }

      const pending = await base44.asServiceRole.entities.GuildApplication.filter({
        guild_id: guildId,
        status: 'pending',
      });

      return Response.json({ success: true, applications: pending });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});