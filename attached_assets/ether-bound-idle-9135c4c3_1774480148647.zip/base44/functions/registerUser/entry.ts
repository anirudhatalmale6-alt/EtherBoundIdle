import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const { email, username, password } = await req.json();

    if (!email || !username || !password) {
      return Response.json({ error: 'Email, username, and password required' }, { status: 400 });
    }

    if (password.length < 6) {
      return Response.json({ error: 'Password must be at least 6 characters' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);

    // Check if user already exists
    try {
      const existingUsers = await base44.asServiceRole.entities.User.filter({ email });
      if (existingUsers.length > 0) {
        return Response.json({ error: 'Email already registered' }, { status: 400 });
      }
    } catch (e) {
      // Continue - might fail if no access
    }

    // Invite user with 'user' role via Base44's native system
    // This creates a User record and sends invitation email
    await base44.users.inviteUser(email, 'user');

    return Response.json({ 
      success: true, 
      message: 'Account created. Check your email to set your password.',
      email: email,
      username: username
    }, { status: 201 });
  } catch (error) {
    console.error('Register error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});