import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const DAILY_REWARDS = [
  { day: 1,  gold: 500,   gems: 2,   item: null },
  { day: 2,  gold: 750,   gems: 2,   item: null },
  { day: 3,  gold: 1000,  gems: 3,   item: 'exp_scroll' },
  { day: 4,  gold: 1000,  gems: 3,   item: null },
  { day: 5,  gold: 1500,  gems: 5,   item: null },
  { day: 6,  gold: 1500,  gems: 5,   item: 'gold_scroll' },
  { day: 7,  gold: 3000,  gems: 10,  item: null },
  { day: 14, gold: 5000,  gems: 20,  item: 'exp_scroll' },
  { day: 21, gold: 7500,  gems: 30,  item: 'gold_scroll' },
  { day: 30, gold: 10000, gems: 120, item: 'exp_scroll' },
];

function getRewardForDay(day) {
  // Find exact match first, then nearest milestone below
  const exact = DAILY_REWARDS.find(r => r.day === day);
  if (exact) return exact;
  // Default scaling
  const base = Math.min(day, 30);
  return {
    day: base,
    gold: Math.floor(500 * (1 + base * 0.1)),
    gems: Math.max(1, Math.floor(base / 5)),
    item: null
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { characterId } = await req.json();
    const character = await base44.entities.Character.get(characterId);
    if (!character) return Response.json({ error: 'Character not found' }, { status: 404 });

    const today = new Date().toISOString().split('T')[0];

    const logins = await base44.entities.DailyLogin.filter({ character_id: characterId });
    const loginRecord = logins[0];

    if (loginRecord?.last_claimed_date === today) {
      return Response.json({ success: false, alreadyClaimed: true, streak: loginRecord.streak });
    }

    // Calculate streak
    let streak = 1;
    let totalDays = 1;
    if (loginRecord) {
      const lastDate = new Date(loginRecord.last_claimed_date);
      const todayDate = new Date(today);
      const diffDays = Math.floor((todayDate - lastDate) / (1000 * 60 * 60 * 24));
      streak = diffDays === 1 ? (loginRecord.streak || 1) + 1 : 1;
      totalDays = (loginRecord.total_days || 1) + 1;
    }

    const reward = getRewardForDay(streak);

    // Apply rewards
    const updates = {
      gold: (character.gold || 0) + reward.gold,
      gems: (character.gems || 0) + reward.gems,
    };
    await base44.entities.Character.update(characterId, updates);

    // Give scroll item if applicable
    if (reward.item) {
      const scrollData = reward.item === 'exp_scroll'
        ? { name: 'EXP Scroll', type: 'consumable', rarity: 'rare', stats: { exp_gain_pct: 25 }, description: '+25% EXP for 1 hour', sell_price: 500, quantity: 1 }
        : { name: 'Gold Scroll', type: 'consumable', rarity: 'rare', stats: { gold_gain_pct: 25 }, description: '+25% Gold for 1 hour', sell_price: 500, quantity: 1 };
      await base44.entities.Item.create({ ...scrollData, owner_id: characterId });
    }

    // Update or create login record
    if (loginRecord) {
      await base44.entities.DailyLogin.update(loginRecord.id, {
        streak, total_days: totalDays, last_claimed_date: today
      });
    } else {
      await base44.entities.DailyLogin.create({
        character_id: characterId, streak: 1, total_days: 1, last_claimed_date: today
      });
    }

    return Response.json({
      success: true,
      streak,
      totalDays,
      reward: { ...reward, hasItem: !!reward.item }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});