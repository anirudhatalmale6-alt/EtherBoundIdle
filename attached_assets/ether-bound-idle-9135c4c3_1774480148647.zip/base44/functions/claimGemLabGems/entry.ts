import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * Claim pending gems from the Gem Lab
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { characterId } = await req.json();
    if (!characterId) {
      return Response.json({ error: 'Character ID required' }, { status: 400 });
    }

    // Get character
    const character = await base44.entities.Character.get(characterId);
    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Get GemLab
    const labs = await base44.entities.GemLab.filter({ character_id: characterId });
    const lab = labs[0];

    if (!lab || lab.pending_gems <= 0) {
      return Response.json({ error: 'No pending gems to claim' }, { status: 400 });
    }

    // Claim gems - add to character
    const claimedGems = Math.floor(lab.pending_gems);
    const newCharacterGems = (character.gems || 0) + claimedGems;

    // Update both
    await Promise.all([
      base44.entities.Character.update(characterId, { gems: newCharacterGems }),
      base44.entities.GemLab.update(lab.id, { pending_gems: lab.pending_gems - claimedGems }),
    ]);

    return Response.json({
      success: true,
      claimedGems: claimedGems,
      newTotal: newCharacterGems,
      remainingPending: lab.pending_gems - claimedGems,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});