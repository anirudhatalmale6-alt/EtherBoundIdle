import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Get current user from Base44's native auth
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Map Base44 User data to game format
    const username = user.full_name || user.email.split('@')[0];
    const role = user.role || 'user';

    return Response.json({
      id: user.id,
      email: user.email,
      full_name: user.full_name,
      username: username,
      role: role, // Keep raw role: 'user', 'admin', etc.
    }, { status: 200 });
  } catch (error) {
    console.error('Get current user error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});