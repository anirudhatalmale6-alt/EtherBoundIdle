import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || (user.role !== 'admin' && user.role !== 'superadmin')) {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const characters = await base44.asServiceRole.entities.Character.list();
    return Response.json({ characters });
  } catch (error) {
    console.error('getAllCharacters error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});