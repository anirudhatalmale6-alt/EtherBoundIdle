import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const character = await base44.entities.Character.filter({
      created_by: user.email
    }).then(chars => chars[0]);

    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // TRANSMUTATION CONSTANTS
    const BASE_COST = 1000;
    const SCALING_FACTOR = 1.5; // 50% cost increase per transmutation
    const BASE_GEM_REWARD = 0.1; // 0.1 gems per transmutation early
    
    // Calculate cost for this transmutation
    const cost = Math.floor(BASE_COST * Math.pow(SCALING_FACTOR, character.transmutation_count || 0));
    
    // Check if player has enough gold
    if ((character.gold || 0) < cost) {
      return Response.json({
        error: 'Not enough gold',
        required: cost,
        current: character.gold || 0
      }, { status: 400 });
    }

    // Calculate gem reward
    // Efficiency bonus: +0.01% per transmutation (compounds slowly)
    const efficiencyBonus = 1 + (character.transmutation_count || 0) * 0.0001;
    const gemsGained = parseFloat((BASE_GEM_REWARD * efficiencyBonus).toFixed(4));

    // Update character
    const newGold = character.gold - cost;
    const newGems = (character.gems || 0) + gemsGained;
    const newCount = (character.transmutation_count || 0) + 1;

    await base44.entities.Character.update(character.id, {
      gold: newGold,
      gems: newGems,
      transmutation_count: newCount
    });

    return Response.json({
      success: true,
      goldSpent: cost,
      gemsGained: parseFloat(gemsGained.toFixed(4)),
      newGold,
      newGems: parseFloat(newGems.toFixed(4)),
      totalTransmutations: newCount,
      nextCost: Math.floor(BASE_COST * Math.pow(SCALING_FACTOR, newCount))
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});