import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// Process offline progression every 5 minutes
// Handles: Life Skills (mining, fishing, herbalism) + Gem Lab

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user?.email) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get all characters for this user
    const characters = await base44.entities.Character.filter({ created_by: user.email });

    const results = [];

    for (const character of characters) {
      // ── LIFE SKILLS TICK ──────────────────────────────────
      const lifeSkills = await base44.entities.LifeSkill.filter({ character_id: character.id });

      for (const skill of lifeSkills) {
        if (!skill.is_active) continue;

        const now = new Date();
        const lastTick = skill.last_tick_at ? new Date(skill.last_tick_at) : skill.session_started_at ? new Date(skill.session_started_at) : now;
        const secondsElapsed = (now - lastTick) / 1000;
        const ticksElapsed = Math.floor(secondsElapsed / 300); // 5 min = 300s

        if (ticksElapsed === 0) continue;

        // Calculate progress (speed_level affects gathering speed)
        const baseProgress = 10 + skill.speed_level * 2;
        const progressGain = baseProgress * ticksElapsed;
        const newProgress = (skill.gather_progress || 0) + progressGain;

        // Luck affects rare drops (simplified)
        const luckBonus = Math.min(skill.luck_level * 2, 20);
        const dropChance = 0.05 + luckBonus / 1000;
        const resourcesGained = Math.floor(ticksElapsed * (1 + Math.random() * dropChance));

        // EXP gain
        const expPerTick = 5 + skill.level * 0.5;
        const expGain = Math.floor(expPerTick * ticksElapsed);
        let newExp = (skill.exp || 0) + expGain;
        let newLevel = skill.level;
        let newExpToNext = skill.exp_to_next;

        // Level up if needed
        while (newExp >= newExpToNext) {
          newExp -= newExpToNext;
          newLevel++;
          newExpToNext = Math.floor(100 * Math.pow(1.15, newLevel - 1));
        }

        // Update skill
        await base44.entities.LifeSkill.update(skill.id, {
          gather_progress: newProgress,
          exp: newExp,
          level: newLevel,
          exp_to_next: newExpToNext,
          last_tick_at: new Date().toISOString(),
        });

        // Add resources to inventory
        if (resourcesGained > 0) {
          const resourceType = {
            mining: ['iron_ore', 'copper_ore', 'silver_ore', 'gold_ore'][Math.floor(Math.random() * 4)],
            fishing: ['carp', 'salmon', 'tuna'][Math.floor(Math.random() * 3)],
            herbalism: ['common_herb', 'greenleaf', 'blue_herb'][Math.floor(Math.random() * 3)],
          }[skill.skill_type] || 'common_herb';

          const existing = await base44.entities.Resource.filter({
            character_id: character.id,
            resource_type: resourceType,
          });

          if (existing[0]) {
            await base44.entities.Resource.update(existing[0].id, {
              quantity: existing[0].quantity + resourcesGained,
            });
          } else {
            await base44.entities.Resource.create({
              character_id: character.id,
              resource_type: resourceType,
              quantity: resourcesGained,
              rarity: 'common',
            });
          }
        }

        results.push({
          character: character.name,
          skill: skill.skill_type,
          exp_gained: expGain,
          level: newLevel,
          resources_gained: resourcesGained,
        });
      }

      // ── GEM LAB TICK ──────────────────────────────────
      const gemLab = await base44.entities.GemLab.filter({ character_id: character.id });

      if (gemLab[0]) {
        const lab = gemLab[0];
        const now = new Date();
        const lastCollection = lab.last_collection_time ? new Date(lab.last_collection_time) : now;
        const secondsElapsed = (now - lastCollection) / 1000;
        const ticksElapsed = Math.floor(secondsElapsed / 300); // 5 min = 300s

        if (ticksElapsed > 0) {
          // Calculate gem production
          const baseProduction = 5 + lab.production_level;
          const speedMultiplier = 1 + lab.speed_level * 0.1;
          const efficiencyMultiplier = 1 + lab.efficiency_level * 0.05;

          const gemsPerTick = Math.floor(baseProduction * speedMultiplier * efficiencyMultiplier);
          const gemsGained = gemsPerTick * ticksElapsed;

          await base44.entities.GemLab.update(lab.id, {
            pending_gems: (lab.pending_gems || 0) + gemsGained,
            total_gems_generated: (lab.total_gems_generated || 0) + gemsGained,
            last_collection_time: new Date().toISOString(),
          });

          results.push({
            character: character.name,
            system: 'gem_lab',
            gems_gained: gemsGained,
          });
        }
      }
    }

    return Response.json({
      success: true,
      processed: results.length,
      details: results,
    });
  } catch (error) {
    console.error('Offline progression tick error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});