import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { characterId, action } = body;

    if (!characterId) return Response.json({ error: 'Missing characterId' }, { status: 400 });

    // Verify ownership
    const char = await base44.asServiceRole.entities.Character.filter({ id: characterId, created_by: user.email });
    if (!char[0]) return Response.json({ error: 'Character not found' }, { status: 404 });

    // Get or create session
    const sessions = await base44.asServiceRole.entities.PlayerSession.filter({ character_id: characterId });
    let session = sessions[0];

    if (!session) {
      session = await base44.asServiceRole.entities.PlayerSession.create({
        character_id: characterId,
        last_active: new Date().toISOString(),
        last_sync: new Date().toISOString(),
        active_skill: null,
        skill_progress: 0,
        combat_active: false,
        daily_limits: {
          guild_boss_uses: 0,
          dungeon_entries: 0,
          last_limit_reset: new Date().toISOString(),
        },
      });
    }

    const now = new Date();
    const lastSync = new Date(session.last_sync || session.created_date);
    const offlineMinutes = Math.floor((now - lastSync) / 60000);

    // ACTION: sync_progression
    if (action === 'sync_progression') {
      const results = {
        offline_minutes: offlineMinutes,
        exp_gained: 0,
        resources_gained: {},
        gems_gained: 0,
      };

      // ─── LIFE SKILLS PROGRESSION ───
      if (session.active_skill && offlineMinutes > 0) {
        const lifeSkills = await base44.asServiceRole.entities.LifeSkill.filter({
          character_id: characterId,
          skill_type: session.active_skill,
        });

        if (lifeSkills[0]) {
          const skill = lifeSkills[0];
          const ticks = Math.floor(offlineMinutes / 5); // 1 tick per 5 minutes
          let totalGathered = 0;

          for (let i = 0; i < ticks; i++) {
            const gatherRate = 10 + skill.speed_level * 2;
            const luckBonus = Math.random() * skill.luck_level;
            const gathered = Math.floor(gatherRate + luckBonus);
            totalGathered += gathered;

            // Level up check
            skill.gather_progress = (skill.gather_progress || 0) + gathered;
            if (skill.gather_progress >= 100) {
              skill.exp += Math.floor(skill.gather_progress / 100) * 10;
              skill.gather_progress = skill.gather_progress % 100;

              // Check level up
              const expPerLevel = 100 + skill.level * 50;
              if (skill.exp >= expPerLevel) {
                skill.level++;
                skill.exp = skill.exp - expPerLevel;
              }
            }
          }

          await base44.asServiceRole.entities.LifeSkill.update(skill.id, {
            gather_progress: skill.gather_progress,
            exp: skill.exp,
            level: skill.level,
          });

          // Add resources to inventory
          if (totalGathered > 0) {
            const resourceTypes = {
              mining: ['iron_ore', 'copper_ore', 'silver_ore'],
              fishing: ['carp', 'salmon', 'tuna'],
              herbalism: ['common_herb', 'greenleaf', 'blue_herb'],
            };

            const typeKey = session.active_skill;
            const resType = resourceTypes[typeKey][Math.floor(Math.random() * 3)];

            const existing = await base44.asServiceRole.entities.Resource.filter({
              character_id: characterId,
              resource_type: resType,
            });

            if (existing[0]) {
              await base44.asServiceRole.entities.Resource.update(existing[0].id, {
                quantity: (existing[0].quantity || 0) + totalGathered,
              });
            } else {
              await base44.asServiceRole.entities.Resource.create({
                character_id: characterId,
                resource_type: resType,
                quantity: totalGathered,
                rarity: 'common',
              });
            }

            results.resources_gained[resType] = totalGathered;
          }
        }
      }

      // ─── GEM LAB PROGRESSION ───
      const gemLab = await base44.asServiceRole.entities.GemLab.filter({ character_id: characterId });
      if (gemLab[0]) {
        const lab = gemLab[0];
        const lastCollect = new Date(lab.last_collection_time || lastSync);
        const gemsMinutes = Math.floor((now - lastCollect) / 60000);

        if (gemsMinutes > 0) {
          // Base rate: 1 gem per minute
          let gemsGenerated = gemsMinutes;

          // Production bonus: +2 per level
          gemsGenerated += lab.production_level * 2;

          // Speed bonus: 10% per level
          const speedMult = 1 + (lab.speed_level * 0.1);
          gemsGenerated = Math.floor(gemsGenerated * speedMult);

          // Efficiency bonus: increase final output
          const effMult = 1 + (lab.efficiency_level * 0.05);
          gemsGenerated = Math.floor(gemsGenerated * effMult);

          await base44.asServiceRole.entities.GemLab.update(lab.id, {
            pending_gems: (lab.pending_gems || 0) + gemsGenerated,
            total_gems_generated: (lab.total_gems_generated || 0) + gemsGenerated,
            last_collection_time: now.toISOString(),
          });

          results.gems_gained = gemsGenerated;
        }
      }

      // ─── DAILY LIMIT RESET ───
      const lastReset = new Date(session.daily_limits?.last_limit_reset || now);
      const daysSinceReset = Math.floor((now - lastReset) / (24 * 60 * 60000));

      if (daysSinceReset >= 1) {
        await base44.asServiceRole.entities.PlayerSession.update(session.id, {
          daily_limits: {
            guild_boss_uses: 0,
            dungeon_entries: 0,
            last_limit_reset: now.toISOString(),
          },
        });
      }

      // Update session
      await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        last_active: now.toISOString(),
        last_sync: now.toISOString(),
        offline_duration_minutes: 0,
      });

      return Response.json({ success: true, results });
    }

    // ACTION: start_skill
    if (action === 'start_skill') {
      const { skillType } = body;
      if (!['mining', 'fishing', 'herbalism'].includes(skillType)) {
        return Response.json({ error: 'Invalid skill type' }, { status: 400 });
      }

      await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        active_skill: skillType,
        skill_progress: 0,
        last_active: now.toISOString(),
      });

      return Response.json({ success: true, message: `Started ${skillType}` });
    }

    // ACTION: stop_skill
    if (action === 'stop_skill') {
      await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        active_skill: null,
        skill_progress: 0,
        last_active: now.toISOString(),
      });

      return Response.json({ success: true });
    }

    // ACTION: save_combat
    if (action === 'save_combat') {
      const { enemyKey, enemyHp, enemyMaxHp, playerHp, playerMp, phase } = body;

      await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        combat_active: true,
        combat_state: {
          enemy_key: enemyKey,
          enemy_hp: enemyHp,
          enemy_max_hp: enemyMaxHp,
          player_hp: playerHp,
          player_mp: playerMp,
          phase,
        },
        last_active: now.toISOString(),
      });

      return Response.json({ success: true });
    }

    // ACTION: clear_combat
    if (action === 'clear_combat') {
      await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        combat_active: false,
        combat_state: null,
        last_active: now.toISOString(),
      });

      return Response.json({ success: true });
    }

    // ACTION: check_limit (guild boss or dungeon)
    if (action === 'check_limit') {
      const { limitType, cost } = body; // limitType: 'guild_boss' | 'dungeon', cost: gems required for extra

      const session = sessions[0];
      const limits = session?.daily_limits || { guild_boss_uses: 0, dungeon_entries: 0 };

      // Reset if new day
      const lastReset = new Date(limits.last_limit_reset || now);
      const daysSinceReset = Math.floor((now - lastReset) / (24 * 60 * 60000));
      if (daysSinceReset >= 1) {
        limits.guild_boss_uses = 0;
        limits.dungeon_entries = 0;
        limits.last_limit_reset = now.toISOString();
      }

      const maxFree = limitType === 'guild_boss' ? 3 : 2;
      const maxWithGems = limitType === 'guild_boss' ? 5 : 4;

      if (limitType === 'guild_boss') {
        const uses = limits.guild_boss_uses || 0;

        if (uses >= maxFree) {
          // Need gems for extra
          const char = await base44.asServiceRole.entities.Character.filter({ id: characterId });
          if (char[0].gems < cost) {
            return Response.json({ allowed: false, reason: 'insufficient_gems', required: cost }, { status: 402 });
          }

          if (uses >= maxWithGems) {
            return Response.json({ allowed: false, reason: 'limit_reached' }, { status: 403 });
          }

          // Charge gems
          await base44.asServiceRole.entities.Character.update(char[0].id, {
            gems: char[0].gems - cost,
          });

          limits.guild_boss_uses = uses + 1;
        } else {
          limits.guild_boss_uses = uses + 1;
        }
      }

      if (limitType === 'dungeon') {
        const entries = limits.dungeon_entries || 0;

        if (entries >= maxFree) {
          const char = await base44.asServiceRole.entities.Character.filter({ id: characterId });
          if (char[0].gems < cost) {
            return Response.json({ allowed: false, reason: 'insufficient_gems', required: cost }, { status: 402 });
          }

          if (entries >= maxWithGems) {
            return Response.json({ allowed: false, reason: 'limit_reached' }, { status: 403 });
          }

          // Charge gems
          await base44.asServiceRole.entities.Character.update(char[0].id, {
            gems: char[0].gems - cost,
          });

          limits.dungeon_entries = entries + 1;
        } else {
          limits.dungeon_entries = entries + 1;
        }
      }

      await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        daily_limits: limits,
        last_active: now.toISOString(),
      });

      return Response.json({ allowed: true, remaining_free: limitType === 'guild_boss' ? maxFree - limits.guild_boss_uses : maxFree - limits.dungeon_entries });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});