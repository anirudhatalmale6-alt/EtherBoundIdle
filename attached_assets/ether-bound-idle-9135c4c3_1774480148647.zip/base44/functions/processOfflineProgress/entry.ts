import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { characterId } = await req.json();
    const character = await base44.entities.Character.get(characterId);
    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Calculate time offline (in hours, cap at 168 hours = 7 days)
    const now = new Date();
    const lastLogin = character.last_login ? new Date(character.last_login) : new Date(character.created_date);
    let hoursOffline = (now - lastLogin) / (1000 * 60 * 60);
    hoursOffline = Math.min(hoursOffline, 168); // Cap at 7 days
    if (hoursOffline < 0.01) {
      // Less than ~36 seconds, no meaningful progress
      return Response.json({
        success: true,
        hoursOffline: 0,
        rewards: { gems: 0, gold: 0, exp: 0, ores: 0, items: [] },
      });
    }

    const rewards = {
      gems: 0,
      gold: 0,
      exp: 0,
      ores: 0,
      items: [],
    };

    // ===== GEM LAB =====
    const gemLabs = await base44.entities.GemLab.filter({ character_id: characterId });
    const gemLab = gemLabs[0];
    if (gemLab) {
      const BASE_PRODUCTION = 0.001;
      const prodMult = 1 + (gemLab.production_level * 0.05);
      const speedMult = 1 + (gemLab.speed_level * 0.02);
      const effMult = 1 + (gemLab.efficiency_level * 0.03);

      const gemsPerCycle = BASE_PRODUCTION * prodMult * effMult;
      const cycleTimeMins = 10 / speedMult;
      const cyclesCompleted = Math.floor((hoursOffline * 60) / cycleTimeMins);
      const gemsGenerated = cyclesCompleted * gemsPerCycle;

      rewards.gems = Math.floor(gemsGenerated);

      // Update GemLab last_collection_time
      await base44.entities.GemLab.update(gemLab.id, {
        total_gems_generated: (gemLab.total_gems_generated || 0) + gemsGenerated,
        last_collection_time: now.toISOString(),
        pending_gems: (gemLab.pending_gems || 0) + gemsGenerated,
      });
    }

    // ===== COMBAT REWARDS (Fighting passive) =====
    // Players engage in combat continuously while offline
    // Average fight gives: 50 gold, 30 exp per fight (~10 seconds per fight = 360 fights per hour)
    const FIGHTS_PER_HOUR = 360; // 10 sec per fight
    const GOLD_PER_FIGHT = 50;
    const EXP_PER_FIGHT = 30;
    const totalFights = Math.floor(hoursOffline * FIGHTS_PER_HOUR);
    const fightGold = Math.floor(totalFights * GOLD_PER_FIGHT);
    const fightExp = Math.floor(totalFights * EXP_PER_FIGHT);
    rewards.gold += fightGold;
    rewards.exp += fightExp;

    // ===== LIFE SKILLS (Mining, Fishing, Herbalism) - PARALLEL WITH FIGHTING =====
    // All skills run SIMULTANEOUSLY with combat, not after
    const lifeSkills = await base44.entities.LifeSkill.filter({ character_id: characterId });
    if (lifeSkills.length > 0) {
      for (const skill of lifeSkills) {
        if (!skill.is_active) continue;

        // Base rate: 1 ore per 5 seconds (720 per hour)
        const baseRatePerHour = 720;
        const speedBonus = 1 + (skill.speed_level * 0.05);
        const itemsProducedPerHour = baseRatePerHour * speedBonus;
        const totalItems = Math.floor(hoursOffline * itemsProducedPerHour);

        if (skill.skill_type === 'mining') {
          rewards.ores += totalItems;
        } else if (skill.skill_type === 'fishing') {
          // Fishing produces fewer items but more value - 240 per hour base
          const fishPerHour = 240 * speedBonus;
          const fishCount = Math.floor(hoursOffline * fishPerHour);
          rewards.gold += Math.floor(fishCount * 15); // Higher value per fish
        } else if (skill.skill_type === 'herbalism') {
          // Herbalism - 300 per hour base
          const herbsPerHour = 300 * speedBonus;
          const herbCount = Math.floor(hoursOffline * herbsPerHour);
          rewards.gold += Math.floor(herbCount * 8); // Medium value per herb
        }

        // Update skill experience (same rate for all skills)
        const skillExpPerHour = 150;
        const skillExp = Math.floor(hoursOffline * skillExpPerHour);
        let newExp = (skill.exp || 0) + skillExp;
        let newLevel = skill.level;
        let expToNext = 1000;

        while (newExp >= expToNext) {
          newExp -= expToNext;
          newLevel++;
          expToNext = Math.floor(expToNext * 1.1);
        }

        await base44.entities.LifeSkill.update(skill.id, {
          exp: newExp,
          level: newLevel,
          last_tick_at: now.toISOString(),
        });
      }
    }

    // ===== CHARACTER UPDATES =====
    let newExp = (character.exp || 0) + rewards.exp;
    let newLevel = character.level;
    let newExpToNext = character.exp_to_next;
    let newStatPoints = character.stat_points || 0;
    let newSkillPoints = character.skill_points || 0;

    // Process level ups from idle exp
    const { calculateExpToLevel } = await import('../lib/gameData.js').catch(() => ({
      calculateExpToLevel: (level) => 100 * Math.pow(1.1, level - 1),
    }));

    while (newExp >= newExpToNext) {
      newExp -= newExpToNext;
      newLevel++;
      newExpToNext = calculateExpToLevel(newLevel);
      newStatPoints += 3;
      newSkillPoints += 1;
    }

    // Update character
    await base44.entities.Character.update(characterId, {
      gold: (character.gold || 0) + rewards.gold,
      gems: (character.gems || 0) + rewards.gems,
      exp: newExp,
      level: newLevel,
      exp_to_next: newExpToNext,
      stat_points: newStatPoints,
      skill_points: newSkillPoints,
      last_login: now.toISOString(),
    });

    return Response.json({
      success: true,
      hoursOffline: hoursOffline.toFixed(2),
      rewards,
    });
  } catch (error) {
    console.error('Offline progress error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});