/**
 * GAME CONFIG MANAGER — Backend Function
 * 
 * GET  → gibt die aktuelle gespeicherte Konfiguration zurück
 * POST → speichert eine neue Konfiguration (Admin only)
 * 
 * Die Konfiguration wird als eine einzige Entity in der DB gespeichert
 * (Entity: "GameConfig", immer nur 1 Datensatz)
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// ── DEFAULT CONFIG (Fallback wenn noch nichts in DB gespeichert) ──────────────
const DEFAULT_CONFIG = {
  PROGRESSION: {
    BASE_EXP: 100,
    EXP_GROWTH: 1.15,
    STAT_POINTS_PER_LEVEL: 3,
    SKILL_POINTS_PER_LEVEL: 1,
    HP_PER_LEVEL: 5,
    MP_PER_LEVEL: 3,
    MAX_LEVEL: 100,
  },
  COMBAT: {
    BASE_ATTACK_INTERVAL_MS: 1000,
    BASE_CRIT_CHANCE: 0.05,
    CRIT_DAMAGE_MULTIPLIER: 1.5,
    BASE_EVASION: 0.05,
    BASE_BLOCK: 0.05,
    BLOCK_REDUCTION: 0.5,
    DEFENSE_TO_REDUCTION: 0.002,
    MAX_DAMAGE_REDUCTION: 0.6,
    MAX_LIFESTEAL: 50,
    ENEMY_DMG_VARIANCE: 0.4,
    IDLE_REWARD_MULTIPLIER: 0.5,
    AUTO_POTION_THRESHOLD: 0.4,
  },
  ECONOMY: {
    STARTING_GOLD: 100,
    STARTING_GEMS: 10,
    MAX_OFFLINE_HOURS: 168,
    TRANSMUTE_COST_BASE: 1000,
    TRANSMUTE_COST_SCALING: 1.5,
    TRANSMUTE_GEMS_REWARD: 1,
    GEM_LAB_BASE_RATE: 0.1,
    GEM_LAB_PRODUCTION_BONUS: 0.05,
    GEM_LAB_SPEED_REDUCTION: 0.1,
    GEM_LAB_EFFICIENCY_BONUS: 0.1,
    SHOP_ROTATION_HOURS: 4,
  },
  LOOT: {
    BASE_DROP_CHANCE: 0.01,
    MAX_DROP_CHANCE: 0.04,
    LUCK_DROP_BONUS: 0.0003,
    BOSS_DROP_CHANCE: 0.25,
    SMART_LOOT_CHANCE: 0.65,
    SMART_LOOT_WEAPON_CHANCE: 0.40,
    SMART_LOOT_ARMOR_CHANCE: 0.35,
    LUCK_RARITY_BONUS_PER_POINT: 0.1,
  },
  UPGRADES: {
    SAFE_GOLD_BASE: 500,
    SAFE_GOLD_SCALING: 1,
    SAFE_ORE_BASE: 5,
    SAFE_ORE_SCALING: 2,
    SAFE_STAT_BONUS_PER_LEVEL: 0.02,
    SAFE_MAX_LEVEL: 20,
    STAR_SUCCESS_CHANCES: [90, 75, 50, 35, 12, 8, 2],
    STAR_GEM_BASE: 5,
    STAR_GEM_GROWTH: 1.5,
    STAR_STAT_BONUS_PER_STAR: 0.05,
    STAR_MAX_LEVEL: 7,
    AWAKEN_GEM_COST: 50,
    AWAKEN_STAT_BONUS: 0.5,
  },
  GUILDS: {
    MAX_MEMBERS: 20,
    MAX_LEVEL: 30,
    BASE_EXP_TO_NEXT: 1000,
    EXP_GROWTH: 1.3,
    PERK_BONUS_PER_LEVEL: 0.05,
    MAX_PERK_LEVEL: 10,
    BOSS_RESPAWN_HOURS: 24,
    BOSS_HP_BASE: 10000,
    BOSS_HP_PER_GUILD_LEVEL: 5000,
    TOKEN_REWARD_PER_BOSS_DAMAGE: 0.01,
  },
  PARTIES: {
    MAX_SIZE: 6,
    EXP_BONUS_PER_MEMBER: 0.05,
    GOLD_BONUS_PER_MEMBER: 0.05,
    INVITE_EXPIRY_MINUTES: 5,
  },
  DAILY_LOGIN: {
    BASE_GOLD: 100,
    BASE_GEMS: 2,
    STREAK_GOLD_MULTIPLIER: 1.1,
    MAX_STREAK_BONUS_DAYS: 30,
    MILESTONE_REWARDS: {
      7:  { gems: 10, label: "7-Day Streak!" },
      14: { gems: 25, label: "14-Day Streak!" },
      30: { gems: 60, label: "30-Day Master!" },
    },
  },
  LIFE_SKILLS: {
    BASE_GATHER_TICKS_PER_ITEM: 5,
    SPEED_REDUCTION_PER_LEVEL: 0.1,
    LUCK_RARE_BONUS_PER_LEVEL: 0.05,
    MAX_GATHER_LEVEL: 99,
    EXP_GROWTH: 1.12,
    FIGHTS_PER_HOUR: 360,
    GOLD_PER_FIGHT: 50,
    EXP_PER_FIGHT: 30,
    MINING_ITEMS_PER_HOUR: 720,
    FISHING_ITEMS_PER_HOUR: 240,
    HERBALISM_ITEMS_PER_HOUR: 300,
    FISHING_GOLD_PER_ITEM: 15,
    HERBALISM_GOLD_PER_ITEM: 8,
    SKILL_EXP_PER_HOUR: 150,
    SKILL_EXP_GROWTH: 1.1,
  },
  RARITY_MULTIPLIERS: {
    common: 1.0,
    uncommon: 1.3,
    rare: 1.7,
    epic: 2.2,
    legendary: 3.0,
    mythic: 4.0,
    set: 3.5,
    shiny: 5.0,
  },
  SELL_PRICES: {
    common: 5,
    uncommon: 20,
    rare: 60,
    epic: 200,
    legendary: 600,
    mythic: 2000,
    set: 800,
    shiny: 3000,
  },
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Base44 SDK always sends POST — distinguish by _method field in body
    let body = {};
    try { body = await req.json(); } catch {}
    const method = body._method || req.method;

    // ── GET: return current config ────────────────────────────────────────────
    if (method === 'GET' || !body._method) {
      const configs = await base44.asServiceRole.entities.GameConfig.list('-updated_date', 1);
      if (configs && configs.length > 0) {
        return Response.json({ success: true, config: configs[0].config_data, id: configs[0].id });
      }
      // Return defaults if nothing stored yet
      return Response.json({ success: true, config: DEFAULT_CONFIG, id: null });
    }

    // ── POST: save config (admin only) ────────────────────────────────────────
    if (method === 'POST' && body._method === 'POST') {
      if (user.role !== 'admin' && user.role !== 'superadmin') {
        return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
      }

      const { config, id } = body;

      if (!config || typeof config !== 'object') {
        return Response.json({ error: 'Invalid config data' }, { status: 400 });
      }

      let saved;
      if (id) {
        // Update existing
        saved = await base44.asServiceRole.entities.GameConfig.update(id, {
          config_data: config,
          updated_by: user.email,
        });
      } else {
        // Check if one already exists
        const existing = await base44.asServiceRole.entities.GameConfig.list('-updated_date', 1);
        if (existing && existing.length > 0) {
          saved = await base44.asServiceRole.entities.GameConfig.update(existing[0].id, {
            config_data: config,
            updated_by: user.email,
          });
        } else {
          saved = await base44.asServiceRole.entities.GameConfig.create({
            config_data: config,
            updated_by: user.email,
          });
        }
      }

      return Response.json({ success: true, id: saved.id });
    }

    return Response.json({ error: 'Method not allowed' }, { status: 405 });

  } catch (error) {
    console.error('GameConfig error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});