import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * Process passive gem generation for a character
 * Supports offline progression up to 24 hours
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get character ID from payload
    const { characterId } = await req.json();
    if (!characterId) {
      return Response.json({ error: 'Character ID required' }, { status: 400 });
    }

    // Fetch character and GemLab
    const character = await base44.entities.Character.get(characterId);
    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Fetch or initialize GemLab
    const labs = await base44.entities.GemLab.filter({ character_id: characterId });
    let lab = labs[0];
    
    if (!lab) {
      // First time - initialize
      lab = await base44.entities.GemLab.create({
        character_id: characterId,
        last_collection_time: new Date().toISOString(),
        pending_gems: 0,
      });
    }

    // ===== CALCULATION =====
    // Base production: 0.001 gems per cycle
    const BASE_PRODUCTION = 0.001;
    const CYCLE_TIME_MS = 10 * 60 * 1000; // 10 minutes

    // Scaling formulas (exponential)
    const productionMultiplier = 1 + (lab.production_level * 0.05); // +5% per level
    const speedMultiplier = 1 + (lab.speed_level * 0.02); // -2% cycle time per level
    const efficiencyMultiplier = 1 + (lab.efficiency_level * 0.03); // +3% per level

    // Calculate effective cycle time (reduced by speed upgrades)
    const effectiveCycleTime = CYCLE_TIME_MS / speedMultiplier;

    // Calculate gem production rate per cycle
    const gemsPerCycle = BASE_PRODUCTION * productionMultiplier * efficiencyMultiplier;

    // ===== TIME ELAPSED =====
    const lastCollection = new Date(lab.last_collection_time);
    const now = new Date();
    let elapsedMs = now.getTime() - lastCollection.getTime();

    // Cap offline progression at 24 hours
    const MAX_OFFLINE_MS = 24 * 60 * 60 * 1000;
    if (elapsedMs > MAX_OFFLINE_MS) {
      elapsedMs = MAX_OFFLINE_MS;
    }

    // ===== GEM GENERATION =====
    // Calculate number of complete cycles
    const completeCycles = Math.floor(elapsedMs / effectiveCycleTime);
    const gemsThisCycle = completeCycles * gemsPerCycle;

    // Add to pending
    const newPendingGems = lab.pending_gems + gemsThisCycle;

    // ===== UPDATE =====
    const updateData = {
      pending_gems: newPendingGems,
      total_gems_generated: lab.total_gems_generated + gemsThisCycle,
      last_collection_time: now.toISOString(),
    };

    await base44.entities.GemLab.update(lab.id, updateData);

    return Response.json({
      success: true,
      gemsGenerated: gemsThisCycle,
      pendingGems: newPendingGems,
      totalGenerated: lab.total_gems_generated + gemsThisCycle,
      cyclesCompleted: completeCycles,
      gemsPerCycle: gemsPerCycle,
      cycleDuration: Math.round(effectiveCycleTime / 1000 / 60, 2), // in minutes
      offlineHours: Math.floor(elapsedMs / (60 * 60 * 1000)),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});