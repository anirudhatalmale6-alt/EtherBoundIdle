import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * UNIFIED TIME-BASED PROGRESSION ENGINE
 * Single source of truth for ALL character progression
 * 
 * Simulates:
 * - Mining (with time-based ore generation)
 * - Combat (with time-based damage & enemy HP)
 * - Skills (XP, level ups)
 * - Gem Lab (continuous generation)
 * - Idle rewards
 * 
 * Key principle: elapsed_time × speed = progress
 * NO timers, NO UI state control
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { characterId, action, payload } = body;

    if (!characterId) {
      return Response.json({ error: 'Missing characterId' }, { status: 400 });
    }

    // Get or create character session (source of truth)
    let session = (await base44.asServiceRole.entities.PlayerSession.filter({ character_id: characterId }))[0];
    const character = await base44.asServiceRole.entities.Character.filter({ id: characterId }).then(r => r[0]);
    
    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    const now = new Date();
    const nowTime = now.getTime();

    // Initialize session if needed
    if (!session) {
      session = await base44.asServiceRole.entities.PlayerSession.create({
        character_id: characterId,
        last_active: now.toISOString(),
        last_sync: now.toISOString(),
        active_skill: null,
        skill_progress: 0,
        combat_active: false,
        daily_limits: {
          guild_boss_uses: 0,
          dungeon_entries: 0,
          last_limit_reset: now.toISOString(),
        },
      });
    }

    const lastSyncTime = new Date(session.last_sync).getTime();
    const elapsedMs = nowTime - lastSyncTime;
    const elapsedSec = elapsedMs / 1000;

    // ════════════════════════════════════════════════════════════════════════════
    // PROCESS: Sync and simulate all progression
    // ════════════════════════════════════════════════════════════════════════════
    if (action === 'sync_state' || !action) {
      return syncPlayerState(base44, character, session, elapsedSec, now);
    }

    // ════════════════════════════════════════════════════════════════════════════
    // ACTION: Start skill (mining, fishing, herbalism)
    // ════════════════════════════════════════════════════════════════════════════
    if (action === 'start_skill') {
      const skillType = payload.skill_type;
      if (!['mining', 'fishing', 'herbalism'].includes(skillType)) {
        return Response.json({ error: 'Invalid skill' }, { status: 400 });
      }

      session = await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        active_skill: skillType,
        skill_progress: 0,
        last_sync: now.toISOString(),
      });

      return Response.json({
        success: true,
        message: `Started ${skillType}`,
        session,
      });
    }

    // ════════════════════════════════════════════════════════════════════════════
    // ACTION: Stop skill
    // ════════════════════════════════════════════════════════════════════════════
    if (action === 'stop_skill') {
      session = await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        active_skill: null,
        skill_progress: 0,
        last_sync: now.toISOString(),
      });

      return Response.json({
        success: true,
        message: 'Stopped skill',
        session,
      });
    }

    // ════════════════════════════════════════════════════════════════════════════
    // ACTION: Attack in combat
    // ════════════════════════════════════════════════════════════════════════════
    if (action === 'attack') {
      if (!session.combat_active || !session.combat_state) {
        return Response.json({ error: 'Not in combat' }, { status: 400 });
      }

      const combatState = session.combat_state;
      const damage = payload.damage || 10;
      const newEnemyHP = Math.max(0, combatState.enemy_hp - damage);

      const updated = await base44.asServiceRole.entities.PlayerSession.update(session.id, {
        combat_state: {
          ...combatState,
          enemy_hp: newEnemyHP,
          phase: newEnemyHP <= 0 ? 'enemy_dead' : 'enemy_turn',
        },
        last_sync: now.toISOString(),
      });

      return Response.json({
        success: true,
        damage,
        enemyHp: newEnemyHP,
        isDead: newEnemyHP <= 0,
        session: updated,
      });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    console.error('Progression error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

/**
 * SYNC STATE: Simulate all progress since last update
 */
async function syncPlayerState(base44, character, session, elapsedSec, now) {
  const updates = {};
  let rewards = { exp: 0, gold: 0, gems: 0, resources: [] };

  // ── ACTIVE SKILL SIMULATION ────────────────────────────────────────────────
  if (session.active_skill) {
    const skillType = session.active_skill;
    const skillData = (await base44.asServiceRole.entities.LifeSkill.filter({
      character_id: character.id,
      skill_type: skillType,
    }))[0];

    if (skillData) {
      const cycleTimeMs = 20000; // 20 second gather cycle
      const progressPerSec = 100 / (cycleTimeMs / 1000);
      let progress = session.skill_progress + (progressPerSec * elapsedSec);
      let resourcesGained = 0;

      // Simulate gathering cycles (loop to ensure no skipping)
      while (progress >= 100) {
        progress -= 100;
        resourcesGained++;
        rewards.exp += 15; // XP per resource

        // Generate ore/fish/herb
        const resource = generateResource(character, skillType);
        rewards.resources.push(resource);

        // Create resource in DB
        await base44.asServiceRole.entities.Resource.create({
          character_id: character.id,
          resource_type: resource.type,
          quantity: 1,
          rarity: resource.rarity,
        }).catch(() => {});
      }

      // Update session with new progress
      updates.skill_progress = progress;

      // Update LifeSkill exp
      if (resourcesGained > 0) {
        let newExp = skillData.exp + (resourcesGained * 15);
        let newLevel = skillData.level;
        let expToNext = skillData.exp_to_next;

        while (newExp >= expToNext) {
          newExp -= expToNext;
          newLevel++;
          expToNext = Math.floor(100 * Math.pow(1.1, newLevel));
        }

        await base44.asServiceRole.entities.LifeSkill.update(skillData.id, {
          exp: newExp,
          level: newLevel,
          exp_to_next: expToNext,
        });
      }
    }
  }

  // ── COMBAT SIMULATION ──────────────────────────────────────────────────────
  if (session.combat_active && session.combat_state) {
    const cs = session.combat_state;
    const attacksPerSec = 1; // 1 attack per second
    const attacks = Math.floor(elapsedSec * attacksPerSec);

    let newEnemyHP = cs.enemy_hp;
    let newPlayerExp = 0;

    for (let i = 0; i < attacks; i++) {
      const damage = 10; // Base damage
      newEnemyHP -= damage;

      if (newEnemyHP <= 0) {
        // Enemy defeated
        newPlayerExp += 50;
        updates.combat_active = false;
        updates.combat_state = null;
        break;
      }
    }

    if (updates.combat_active !== false) {
      updates.combat_state = { ...cs, enemy_hp: Math.max(0, newEnemyHP) };
    }

    rewards.exp += newPlayerExp;
  }

  // ── GEM LAB SIMULATION ─────────────────────────────────────────────────────
  const gemLab = (await base44.asServiceRole.entities.GemLab.filter({
    character_id: character.id,
  }))[0];

  if (gemLab) {
    const gemsPerSecond = 0.01; // Base generation rate
    const speedMult = 1 + (gemLab.speed_level * 0.02);
    const effMult = 1 + (gemLab.efficiency_level * 0.03);
    const gemsGenerated = elapsedSec * gemsPerSecond * speedMult * effMult;

    rewards.gems += Math.floor(gemsGenerated * 100) / 100; // Round to 2 decimals

    await base44.asServiceRole.entities.GemLab.update(gemLab.id, {
      pending_gems: (gemLab.pending_gems || 0) + gemsGenerated,
      last_collection_time: now.toISOString(),
    });
  }

  // ── APPLY REWARDS TO CHARACTER ─────────────────────────────────────────────
  let newExp = character.exp + rewards.exp;
  let newLevel = character.level;
  let expToNext = character.exp_to_next;
  let newStatPoints = character.stat_points || 0;

  while (newExp >= expToNext) {
    newExp -= expToNext;
    newLevel++;
    expToNext = Math.floor(100 * Math.pow(1.15, newLevel));
    newStatPoints += 3;
  }

  const charUpdate = {
    exp: newExp,
    level: newLevel,
    exp_to_next: expToNext,
    stat_points: newStatPoints,
    gold: (character.gold || 0) + rewards.gold,
    gems: (character.gems || 0) + Math.floor(rewards.gems),
  };

  // ── UPDATE EVERYTHING ─────────────────────────────────────────────────────
  const updatedSession = await base44.asServiceRole.entities.PlayerSession.update(session.id, {
    ...updates,
    last_sync: now.toISOString(),
    last_active: now.toISOString(),
  });

  const updatedCharacter = await base44.asServiceRole.entities.Character.update(character.id, charUpdate);

  return Response.json({
    success: true,
    elapsed_seconds: elapsedSec,
    character: updatedCharacter,
    session: updatedSession,
    rewards,
  });
}

/**
 * Generate a random resource based on skill type
 */
function generateResource(character, skillType) {
  const resources = {
    mining: [
      { type: 'iron_ore', rarity: 'common' },
      { type: 'copper_ore', rarity: 'common' },
      { type: 'silver_ore', rarity: 'uncommon' },
      { type: 'gold_ore', rarity: 'rare' },
    ],
    fishing: [
      { type: 'carp', rarity: 'common' },
      { type: 'salmon', rarity: 'uncommon' },
      { type: 'tuna', rarity: 'rare' },
    ],
    herbalism: [
      { type: 'common_herb', rarity: 'common' },
      { type: 'greenleaf', rarity: 'uncommon' },
      { type: 'blue_herb', rarity: 'rare' },
    ],
  };

  const list = resources[skillType] || [];
  return list[Math.floor(Math.random() * list.length)] || { type: 'iron_ore', rarity: 'common' };
}