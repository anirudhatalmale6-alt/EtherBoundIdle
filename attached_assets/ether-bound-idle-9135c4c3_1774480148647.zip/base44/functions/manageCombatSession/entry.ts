import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { action, characterId, enemyKey, enemyHp, playerHp, playerMp } = await req.json();

    if (!characterId) {
      return Response.json({ error: 'Character ID required' }, { status: 400 });
    }

    // Verify character ownership
    const char = await base44.entities.Character.filter({ id: characterId }).then(r => r[0]);
    if (!char || char.created_by !== user.email) {
      return Response.json({ error: 'Character not found' }, { status: 403 });
    }

    // Action: get current session
    if (action === 'get_session') {
      const existing = await base44.entities.Character.filter({ id: characterId }).then(r => r[0]);
      return Response.json({
        success: true,
        session: {
          characterId,
          enemyKey: existing.combat_enemy_key || null,
          enemyHp: existing.combat_enemy_hp || 0,
          playerHp: existing.hp || existing.max_hp,
          playerMp: existing.mp || existing.max_mp,
          battleLog: existing.combat_log || [],
          combatPhase: existing.combat_phase || 'idle',
          timestamp: existing.combat_started_at || new Date().toISOString(),
        }
      });
    }

    // Action: save session state
    if (action === 'save_session') {
      await base44.entities.Character.update(characterId, {
        combat_enemy_key: enemyKey,
        combat_enemy_hp: enemyHp,
        hp: playerHp,
        mp: playerMp,
        combat_phase: 'active',
        combat_started_at: new Date().toISOString(),
      });
      return Response.json({ success: true, message: 'Combat session saved' });
    }

    // Action: clear session
    if (action === 'clear_session') {
      await base44.entities.Character.update(characterId, {
        combat_enemy_key: null,
        combat_enemy_hp: 0,
        combat_phase: 'idle',
        combat_started_at: null,
      });
      return Response.json({ success: true, message: 'Combat session cleared' });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});