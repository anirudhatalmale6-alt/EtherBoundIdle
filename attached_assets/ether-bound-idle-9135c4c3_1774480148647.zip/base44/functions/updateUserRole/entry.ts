import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

// Role hierarchy (unified - see roleSystem.js for frontend version)
const ROLE_HIERARCHY = {
  user: 0,
  moderator: 1,
  admin: 2,
  superadmin: 3,
};

function canAssignRole(assignerRole, targetRole) {
  const assignerLevel = ROLE_HIERARCHY[assignerRole] || 0;
  const targetLevel = ROLE_HIERARCHY[targetRole] || 0;
  return assignerLevel > targetLevel && targetLevel > 0;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Only admin+ can change roles
    if (user.role !== 'admin' && user.role !== 'superadmin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { target_user_id, new_role } = await req.json();

    if (!target_user_id || !new_role) {
      return Response.json({ error: 'target_user_id and new_role required' }, { status: 400 });
    }

    // Validate role exists
    if (!ROLE_HIERARCHY.hasOwnProperty(new_role)) {
      return Response.json({ error: 'Invalid role' }, { status: 400 });
    }

    // Prevent self-promotion
    if (target_user_id === user.id) {
      return Response.json({ error: 'Cannot change own role' }, { status: 403 });
    }

    // Get target user from Base44's User entity
    const targetUsers = await base44.asServiceRole.entities.User.filter({ id: target_user_id });
    if (!targetUsers || targetUsers.length === 0) {
      return Response.json({ error: 'User not found' }, { status: 404 });
    }

    const target = targetUsers[0];
    const oldRole = target.role || 'user';

    // Validate hierarchy: can only assign lower roles
    if (!canAssignRole(user.role, new_role)) {
      return Response.json({ error: 'Cannot assign this role (permission denied)' }, { status: 403 });
    }

    // Update user role on Base44's User entity
    const updated = await base44.asServiceRole.entities.User.update(target_user_id, { role: new_role });

    console.log(`[ROLE_CHANGE] Admin: ${user.email} changed ${target.email} from ${oldRole} to ${new_role}`);

    return Response.json({
      success: true,
      user_id: updated.id,
      email: updated.email,
      old_role: oldRole,
      new_role: new_role,
      timestamp: new Date().toISOString(),
    }, { status: 200 });
  } catch (error) {
    console.error('Update role error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});