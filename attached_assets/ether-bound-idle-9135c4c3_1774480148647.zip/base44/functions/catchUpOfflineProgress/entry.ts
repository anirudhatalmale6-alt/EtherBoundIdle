import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// On login: calculate all offline progress for life skills and gem lab
// Returns: resources gained, exp gained, gem production

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user?.email) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { characterId } = body;

    if (!characterId) {
      return Response.json({ error: 'characterId required' }, { status: 400 });
    }

    const character = await base44.entities.Character.filter({ id: characterId });
    if (!character[0] || character[0].created_by !== user.email) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    const char = character[0];
    const results = { lifeSkills: [], gemLab: null };

    // ── LIFE SKILLS CATCH-UP ──────────────────────────────────
    const lifeSkills = await base44.entities.LifeSkill.filter({ character_id: char.id });

    for (const skill of lifeSkills) {
      if (!skill.is_active) continue;

      const now = new Date();
      const lastActive = skill.last_tick_at || skill.session_started_at;
      if (!lastActive) continue;

      const lastTime = new Date(lastActive);
      const hoursOffline = Math.max(0, (now - lastTime) / (1000 * 60 * 60));
      const maxHours = 12; // Cap at 12 hours to prevent abuse
      const effectiveHours = Math.min(hoursOffline, maxHours);

      // Calculate resources & exp for offline duration
      const baseProgress = 10 + skill.speed_level * 2;
      const progressPerHour = baseProgress * 12; // 12 ticks per hour (5min each)
      const totalProgress = progressPerHour * effectiveHours;

      const luckBonus = Math.min(skill.luck_level * 2, 20);
      const dropChance = 0.05 + luckBonus / 1000;
      const resourcesPerHour = Math.floor(12 * (1 + dropChance));
      const resourcesGained = Math.floor(resourcesPerHour * effectiveHours);

      const expPerHour = Math.floor((5 + skill.level * 0.5) * 12);
      const expGain = Math.floor(expPerHour * effectiveHours);
      let newExp = (skill.exp || 0) + expGain;
      let newLevel = skill.level;
      let newExpToNext = skill.exp_to_next;

      while (newExp >= newExpToNext) {
        newExp -= newExpToNext;
        newLevel++;
        newExpToNext = Math.floor(100 * Math.pow(1.15, newLevel - 1));
      }

      // Update skill without stopping it
      await base44.entities.LifeSkill.update(skill.id, {
        gather_progress: (skill.gather_progress || 0) + totalProgress,
        exp: newExp,
        level: newLevel,
        exp_to_next: newExpToNext,
        last_tick_at: new Date().toISOString(),
      });

      // Add resources
      if (resourcesGained > 0) {
        const resourceType = {
          mining: ['iron_ore', 'copper_ore', 'silver_ore', 'gold_ore'][Math.floor(Math.random() * 4)],
          fishing: ['carp', 'salmon', 'tuna'][Math.floor(Math.random() * 3)],
          herbalism: ['common_herb', 'greenleaf', 'blue_herb'][Math.floor(Math.random() * 3)],
        }[skill.skill_type] || 'common_herb';

        const existing = await base44.entities.Resource.filter({
          character_id: char.id,
          resource_type: resourceType,
        });

        if (existing[0]) {
          await base44.entities.Resource.update(existing[0].id, {
            quantity: existing[0].quantity + resourcesGained,
          });
        } else {
          await base44.entities.Resource.create({
            character_id: char.id,
            resource_type: resourceType,
            quantity: resourcesGained,
            rarity: 'common',
          });
        }
      }

      results.lifeSkills.push({
        skill_type: skill.skill_type,
        hours_offline: effectiveHours.toFixed(2),
        resources_gained: resourcesGained,
        exp_gained: expGain,
        new_level: newLevel,
      });
    }

    // ── GEM LAB CATCH-UP ──────────────────────────────────
    const gemLab = await base44.entities.GemLab.filter({ character_id: char.id });

    if (gemLab[0]) {
      const lab = gemLab[0];
      const now = new Date();
      const lastTime = new Date(lab.last_collection_time || lab.created_date);
      const hoursOffline = Math.max(0, (now - lastTime) / (1000 * 60 * 60));
      const maxHours = 12;
      const effectiveHours = Math.min(hoursOffline, maxHours);

      const baseProduction = 5 + lab.production_level;
      const speedMultiplier = 1 + lab.speed_level * 0.1;
      const efficiencyMultiplier = 1 + lab.efficiency_level * 0.05;

      const gemsPerHour = Math.floor((baseProduction * speedMultiplier * efficiencyMultiplier) * 12);
      const gemsGained = Math.floor(gemsPerHour * effectiveHours);

      await base44.entities.GemLab.update(lab.id, {
        pending_gems: (lab.pending_gems || 0) + gemsGained,
        total_gems_generated: (lab.total_gems_generated || 0) + gemsGained,
        last_collection_time: new Date().toISOString(),
      });

      results.gemLab = {
        hours_offline: effectiveHours.toFixed(2),
        gems_gained: gemsGained,
      };
    }

    return Response.json({
      success: true,
      hours_offline: Math.min(hoursOffline || 0, 12),
      results,
    });
  } catch (error) {
    console.error('Catch-up error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});