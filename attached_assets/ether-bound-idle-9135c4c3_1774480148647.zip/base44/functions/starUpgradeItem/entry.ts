import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { itemId } = await req.json();

    // Fetch item and character
    const item = await base44.entities.Item.filter({ id: itemId }).then(items => items[0]);
    const character = await base44.entities.Character.filter({
      created_by: user.email
    }).then(chars => chars[0]);

    if (!item || !character) {
      return Response.json({ error: 'Item or character not found' }, { status: 404 });
    }

    const currentStar = item.star_level || 0;
    if (currentStar >= 7) {
      return Response.json({ error: 'Item at max star level (7)' }, { status: 400 });
    }

    // Success chance decreases dramatically per level
    const successChances = {
      0: 90,  // +1 star
      1: 75,  // +2 star
      2: 50,  // +3 star
      3: 35,  // +4 star
      4: 12,  // +5 star
      5: 8,   // +6 star
      6: 2    // +7 star
    };

    const successChance = successChances[currentStar] || 0;

    // Rarity cost multipliers for star upgrades
    const rarityMultipliers = {
      common: 1.0,
      uncommon: 1.2,
      rare: 1.5,
      epic: 2.0,
      legendary: 2.8,
      mythic: 4.0,
      set: 2.5,
      shiny: 5.0
    };

    const rarityMult = rarityMultipliers[item.rarity] || 1.0;

    // Gem cost: 5 gems per level, increases exponentially, scaled by rarity
    const gemCost = Math.ceil(5 * Math.pow(1.5, currentStar) * rarityMult);

    // Material requirements based on star progression
    let materialType = 'iron_bar'; // Stars 0-2
    let materialQuantity = 1;
    
    if (currentStar >= 3 && currentStar < 5) {
      materialType = 'copper_bar';
      materialQuantity = 2;
    } else if (currentStar >= 5 && currentStar < 7) {
      materialType = 'silver_bar';
      materialQuantity = 3;
    } else if (currentStar === 7) {
      // Awakening uses gold bars
      materialType = 'gold_bar';
      materialQuantity = 1;
    }

    // Check gems
    if ((character.gems || 0) < gemCost) {
      return Response.json({
        error: 'Not enough gems',
        required: gemCost,
        current: character.gems || 0
      }, { status: 400 });
    }

    // Check materials
    const resources = await base44.entities.Resource.filter({
      character_id: character.id,
      resource_type: materialType
    }).then(r => r[0] || null);

    if (!resources || (resources.quantity || 0) < materialQuantity) {
      return Response.json({
        error: `Not enough ${materialType.replace('_', ' ')}`,
        required: materialQuantity,
        current: resources?.quantity || 0
      }, { status: 400 });
    }

    // Deduct gems and materials
    await base44.entities.Character.update(character.id, {
      gems: character.gems - gemCost
    });

    await base44.entities.Resource.update(resources.id, {
      quantity: resources.quantity - materialQuantity
    });

    // Roll for success (brutal: failure = item deleted)
    const rolled = Math.random() * 100;
    const success = rolled < successChance;

    if (success) {
      // Star bonus: +5% per star level
      const bonusMultiplier = 1 + (currentStar + 1) * 0.05;
      const oldStats = item.stats || {};
      const starredStats = {};
      for (const [stat, value] of Object.entries(oldStats)) {
        starredStats[stat] = Math.round(value * bonusMultiplier);
      }

      const updated = await base44.entities.Item.update(item.id, {
        star_level: currentStar + 1,
        stats: starredStats
      });

      return Response.json({
        success: true,
        itemName: item.name,
        newStarLevel: currentStar + 1,
        gemsSpent: gemCost,
        materialUsed: materialType,
        materialQuantity: materialQuantity,
        oldStats,
        newStats: starredStats,
        message: `⭐ SUCCESS! Upgraded to ${currentStar + 1} stars! Stats boosted by ${((bonusMultiplier - 1) * 100).toFixed(1)}%`
      });
    } else {
      // FAILURE: DELETE ITEM (brutal, no exceptions)
      await base44.entities.Item.delete(item.id);

      return Response.json({
        success: false,
        itemName: item.name,
        destroyed: true,
        gemsSpent: gemCost,
        message: `💀 FAILURE! Your ${item.name} has been destroyed!`
      });
    }
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});