import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  let user;
  try { user = await base44.auth.me(); } catch { return Response.json({ error: 'Unauthorized' }, { status: 401 }); }
  if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const { trade_id } = body;
  if (!trade_id) return Response.json({ error: 'Missing trade_id' }, { status: 400 });

  // Fetch trade
  const trades = await base44.asServiceRole.entities.TradeSession.filter({ id: trade_id });
  const trade = trades[0];
  if (!trade) return Response.json({ error: 'Trade not found' }, { status: 404 });
  if (trade.status !== 'initiator_locked' && trade.status !== 'receiver_locked') {
    return Response.json({ error: 'Trade not in locked state' }, { status: 400 });
  }

  // Check expiry
  if (trade.expires_at && new Date(trade.expires_at) < new Date()) {
    await base44.asServiceRole.entities.TradeSession.update(trade.id, { status: 'cancelled' });
    return Response.json({ error: 'Trade expired' }, { status: 400 });
  }

  // Validate both confirmed
  if (!trade.initiator_confirmed || !trade.receiver_confirmed) {
    return Response.json({ error: 'Both players must confirm' }, { status: 400 });
  }

  // Fetch both characters
  const [initiators, receivers] = await Promise.all([
    base44.asServiceRole.entities.Character.filter({ id: trade.initiator_id }),
    base44.asServiceRole.entities.Character.filter({ id: trade.receiver_id }),
  ]);
  const initiator = initiators[0];
  const receiver = receivers[0];
  if (!initiator || !receiver) return Response.json({ error: 'Character not found' }, { status: 404 });

  // Validate gold
  if ((initiator.gold || 0) < (trade.initiator_gold || 0)) {
    return Response.json({ error: 'Initiator insufficient gold' }, { status: 400 });
  }
  if ((receiver.gold || 0) < (trade.receiver_gold || 0)) {
    return Response.json({ error: 'Receiver insufficient gold' }, { status: 400 });
  }

  // Validate item ownership
  const initiatorItemIds = (trade.initiator_items || []).map(i => i.id);
  const receiverItemIds = (trade.receiver_items || []).map(i => i.id);

  const itemValidations = await Promise.all([
    ...initiatorItemIds.map(id => base44.asServiceRole.entities.Item.filter({ id })),
    ...receiverItemIds.map(id => base44.asServiceRole.entities.Item.filter({ id })),
  ]);

  for (let i = 0; i < initiatorItemIds.length; i++) {
    const item = itemValidations[i][0];
    if (!item || item.owner_id !== trade.initiator_id) {
      return Response.json({ error: `Item ${initiatorItemIds[i]} not owned by initiator` }, { status: 400 });
    }
    if (item.equipped) {
      return Response.json({ error: `Cannot trade equipped items` }, { status: 400 });
    }
  }
  for (let i = 0; i < receiverItemIds.length; i++) {
    const item = itemValidations[initiatorItemIds.length + i][0];
    if (!item || item.owner_id !== trade.receiver_id) {
      return Response.json({ error: `Item ${receiverItemIds[i]} not owned by receiver` }, { status: 400 });
    }
    if (item.equipped) {
      return Response.json({ error: `Cannot trade equipped items` }, { status: 400 });
    }
  }

  // Execute trade atomically
  const ops = [];

  // Transfer gold
  const newInitiatorGold = (initiator.gold || 0) - (trade.initiator_gold || 0) + (trade.receiver_gold || 0);
  const newReceiverGold = (receiver.gold || 0) - (trade.receiver_gold || 0) + (trade.initiator_gold || 0);
  ops.push(base44.asServiceRole.entities.Character.update(initiator.id, { gold: newInitiatorGold }));
  ops.push(base44.asServiceRole.entities.Character.update(receiver.id, { gold: newReceiverGold }));

  // Transfer items
  for (const id of initiatorItemIds) {
    ops.push(base44.asServiceRole.entities.Item.update(id, { owner_id: trade.receiver_id }));
  }
  for (const id of receiverItemIds) {
    ops.push(base44.asServiceRole.entities.Item.update(id, { owner_id: trade.initiator_id }));
  }

  // Mark trade complete
  ops.push(base44.asServiceRole.entities.TradeSession.update(trade.id, { status: 'completed' }));

  await Promise.all(ops);

  return Response.json({ success: true });
});