import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Fetch all items with lifesteal > 0
    const allItems = await base44.asServiceRole.entities.Item.list();
    const itemsWithLifesteal = allItems.filter(item => item.stats?.lifesteal > 0);

    if (itemsWithLifesteal.length === 0) {
      return Response.json({ updated: 0, message: 'No items with lifesteal found' });
    }

    // Reduce lifesteal to 20% of original (80% reduction to match new equipment generation)
    const updates = itemsWithLifesteal.map(item =>
      base44.asServiceRole.entities.Item.update(item.id, {
        stats: {
          ...item.stats,
          lifesteal: Math.max(0, Math.round(item.stats.lifesteal * 0.2))
        }
      })
    );

    await Promise.all(updates);

    return Response.json({
      updated: itemsWithLifesteal.length,
      message: `Reduced lifesteal on ${itemsWithLifesteal.length} items`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});