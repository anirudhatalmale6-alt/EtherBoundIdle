/**
 * DUNGEON ACTION HANDLER
 * Handles: create session, join, attack, use_skill, auto_advance_turn
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const BOSS_STATS = {
  inferno_keep:   { name: "Flame Tyrant",   hp: 5000,  dmg: 80,  expReward: 800,  goldReward: 400  },
  frost_citadel:  { name: "Frost Warden",   hp: 12000, dmg: 140, expReward: 1800, goldReward: 800  },
  void_sanctum:   { name: "Void Reaper",    hp: 28000, dmg: 220, expReward: 4500, goldReward: 2000 },
  storm_peak:     { name: "Storm Colossus", hp: 60000, dmg: 350, expReward: 10000,goldReward: 5000 },
};

// Boss-exclusive set item drops (very rare)
const BOSS_SET_DROPS = {
  inferno_keep: [
    { name: "Flame Tyrant's Greatsword", type: "weapon", rarity: "legendary", set_name: "Flame Tyrant", set_key: "flame_tyrant", stats: { damage: 85, strength: 18, fire_dmg: 25, crit_chance: 8 }, boss_drop: "inferno_keep" },
    { name: "Flame Tyrant's Chestplate", type: "armor",  rarity: "legendary", set_name: "Flame Tyrant", set_key: "flame_tyrant", stats: { defense: 60, vitality: 20, fire_dmg: 15, hp_bonus: 200 }, boss_drop: "inferno_keep" },
    { name: "Flame Tyrant's Helm",       type: "helmet", rarity: "legendary", set_name: "Flame Tyrant", set_key: "flame_tyrant", stats: { defense: 40, intelligence: 12, fire_dmg: 20, mp_bonus: 80 }, boss_drop: "inferno_keep" },
  ],
  frost_citadel: [
    { name: "Frost Warden's Blade",      type: "weapon", rarity: "legendary", set_name: "Frost Warden", set_key: "frost_warden", stats: { damage: 110, dexterity: 22, ice_dmg: 30, crit_chance: 10 }, boss_drop: "frost_citadel" },
    { name: "Frost Warden's Robe",       type: "armor",  rarity: "legendary", set_name: "Frost Warden", set_key: "frost_warden", stats: { defense: 75, vitality: 28, ice_dmg: 20, hp_bonus: 280 }, boss_drop: "frost_citadel" },
    { name: "Frost Warden's Crown",      type: "helmet", rarity: "legendary", set_name: "Frost Warden", set_key: "frost_warden", stats: { defense: 55, intelligence: 18, ice_dmg: 25, mp_bonus: 120 }, boss_drop: "frost_citadel" },
  ],
  void_sanctum: [
    { name: "Void Reaper's Scythe",      type: "weapon", rarity: "mythic",    set_name: "Void Reaper",  set_key: "void_reaper",  stats: { damage: 180, strength: 35, blood_dmg: 35, lightning_dmg: 20, crit_chance: 15 }, boss_drop: "void_sanctum" },
    { name: "Void Reaper's Shroud",      type: "armor",  rarity: "mythic",    set_name: "Void Reaper",  set_key: "void_reaper",  stats: { defense: 120, vitality: 40, blood_dmg: 25, hp_bonus: 450, lifesteal: 5 }, boss_drop: "void_sanctum" },
    { name: "Void Reaper's Mask",        type: "helmet", rarity: "mythic",    set_name: "Void Reaper",  set_key: "void_reaper",  stats: { defense: 90, intelligence: 30, poison_dmg: 30, mp_bonus: 200 }, boss_drop: "void_sanctum" },
  ],
  storm_peak: [
    { name: "Storm Colossus' Hammer",    type: "weapon", rarity: "mythic",    set_name: "Storm Colossus", set_key: "storm_colossus", stats: { damage: 280, strength: 55, lightning_dmg: 45, crit_chance: 20, crit_dmg: 50 }, boss_drop: "storm_peak" },
    { name: "Storm Colossus' Aegis",     type: "armor",  rarity: "mythic",    set_name: "Storm Colossus", set_key: "storm_colossus", stats: { defense: 200, vitality: 65, lightning_dmg: 30, hp_bonus: 700, block_chance: 15 }, boss_drop: "storm_peak" },
    { name: "Storm Colossus' Crown",     type: "helmet", rarity: "mythic",    set_name: "Storm Colossus", set_key: "storm_colossus", stats: { defense: 150, intelligence: 50, lightning_dmg: 40, mp_bonus: 350, mp_regen: 10 }, boss_drop: "storm_peak" },
  ],
};

function rollDamage(base, variance = 0.3) {
  return Math.floor(base * (1 - variance + Math.random() * variance * 2));
}

function calcPlayerDmg(member) {
  const base = 30 + (member.level || 1) * 8;
  const isCrit = Math.random() < 0.1;
  return { damage: rollDamage(base) * (isCrit ? 1.5 : 1) | 0, isCrit };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { action, characterId, dungeonId, sessionId, skillId } = body;

    // ── CREATE SESSION ────────────────────────────────────────────────────────
    if (action === 'create') {
      const character = await base44.entities.Character.get(characterId);
      if (!character) return Response.json({ error: 'Character not found' }, { status: 404 });

      const boss = BOSS_STATS[dungeonId];
      if (!boss) return Response.json({ error: 'Unknown dungeon' }, { status: 400 });

      const session = await base44.entities.DungeonSession.create({
        dungeon_id: dungeonId,
        dungeon_name: dungeonId.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        leader_id: characterId,
        status: 'waiting',
        boss_name: boss.name,
        boss_hp: boss.hp,
        boss_max_hp: boss.hp,
        members: [{
          character_id: characterId,
          name: character.name,
          class: character.class,
          level: character.level,
          hp: character.max_hp || 200,
          max_hp: character.max_hp || 200,
          is_ready: true,
        }],
        combat_log: [{ text: `${character.name} created the session. Waiting for members...`, ts: Date.now() }],
        current_turn_index: 0,
        rewards_distributed: false,
      });
      return Response.json({ success: true, session });
    }

    // ── JOIN SESSION ──────────────────────────────────────────────────────────
    if (action === 'join') {
      const session = await base44.entities.DungeonSession.get(sessionId);
      if (!session) return Response.json({ error: 'Session not found' }, { status: 404 });
      if (session.status !== 'waiting') return Response.json({ error: 'Session already started' }, { status: 400 });
      if ((session.members || []).length >= 6) return Response.json({ error: 'Session full' }, { status: 400 });

      const character = await base44.entities.Character.get(characterId);
      if (!character) return Response.json({ error: 'Character not found' }, { status: 404 });

      const alreadyIn = session.members.some(m => m.character_id === characterId);
      if (alreadyIn) return Response.json({ success: true, session });

      const newMembers = [...session.members, {
        character_id: characterId,
        name: character.name,
        class: character.class,
        level: character.level,
        hp: character.max_hp || 200,
        max_hp: character.max_hp || 200,
        is_ready: true,
      }];

      const newLog = [...(session.combat_log || []), { text: `${character.name} joined the dungeon!`, ts: Date.now() }];
      const updated = await base44.entities.DungeonSession.update(sessionId, { members: newMembers, combat_log: newLog.slice(-30) });
      return Response.json({ success: true, session: updated });
    }

    // ── START SESSION ─────────────────────────────────────────────────────────
    if (action === 'start') {
      const session = await base44.entities.DungeonSession.get(sessionId);
      if (!session) return Response.json({ error: 'Session not found' }, { status: 404 });
      if (session.leader_id !== characterId) return Response.json({ error: 'Only leader can start' }, { status: 403 });

      const deadline = new Date(Date.now() + 8000).toISOString(); // 8 seconds per turn
      const updated = await base44.entities.DungeonSession.update(sessionId, {
        status: 'active',
        current_turn_index: 0,
        turn_deadline: deadline,
        combat_log: [...(session.combat_log || []), { text: '⚔️ The dungeon battle begins!', ts: Date.now() }],
      });
      return Response.json({ success: true, session: updated });
    }

    // ── ATTACK / SKILL ────────────────────────────────────────────────────────
    if (action === 'attack' || action === 'skill') {
      const session = await base44.entities.DungeonSession.get(sessionId);
      if (!session || session.status !== 'active') return Response.json({ error: 'Session not active' }, { status: 400 });

      const myIndex = session.members.findIndex(m => m.character_id === characterId);
      if (myIndex === -1) return Response.json({ error: 'Not in session' }, { status: 403 });
      if (session.current_turn_index !== myIndex) return Response.json({ error: 'Not your turn' }, { status: 400 });

      const member = session.members[myIndex];
      const { damage, isCrit } = calcPlayerDmg(member);

      // Skill multiplier
      let finalDmg = damage;
      let actionLabel = `⚔️ Basic Attack`;
      if (action === 'skill' && skillId) {
        finalDmg = Math.floor(damage * 1.8);
        actionLabel = `💥 Skill`;
      }

      const newBossHp = Math.max(0, session.boss_hp - finalDmg);
      const logEntry = {
        text: `${member.name} used ${actionLabel} for ${isCrit ? '💥 CRIT ' : ''}${finalDmg} damage!`,
        ts: Date.now(),
        type: 'player_attack',
        damage: finalDmg,
        isCrit,
      };

      let updates = {
        boss_hp: newBossHp,
        combat_log: [...(session.combat_log || []).slice(-25), logEntry],
      };

      // Check victory
      if (newBossHp <= 0) {
        updates.status = 'victory';
        updates.combat_log = [...updates.combat_log, { text: `🏆 ${session.boss_name} has been defeated!`, ts: Date.now(), type: 'victory' }];

        // Distribute rewards if not done
        if (!session.rewards_distributed) {
          updates.rewards_distributed = true;
          const boss = BOSS_STATS[session.dungeon_id];
          const setDrops = BOSS_SET_DROPS[session.dungeon_id] || [];
          if (boss) {
            for (const m of session.members) {
              if (m.hp <= 0) continue;
              const char = await base44.entities.Character.get(m.character_id).catch(() => null);
              if (char) {
                await base44.entities.Character.update(m.character_id, {
                  gold: (char.gold || 0) + boss.goldReward,
                  exp: (char.exp || 0) + boss.expReward,
                });
                // ~1% chance per set piece per member
                for (const piece of setDrops) {
                  if (Math.random() < 0.01) {
                    await base44.entities.Item.create({
                      ...piece,
                      owner_id: m.character_id,
                      sell_price: piece.rarity === 'mythic' ? 5000 : 2000,
                      buy_price: 0,
                    }).catch(() => {});
                    updates.combat_log = [...(updates.combat_log || []), {
                      text: `🏆 ${m.name} received [${piece.rarity.toUpperCase()}] ${piece.name}!`,
                      ts: Date.now(),
                      type: 'loot',
                    }];
                  }
                }
              }
            }
          }
        }

        const updated = await base44.entities.DungeonSession.update(sessionId, updates);
        return Response.json({ success: true, session: updated });
      }

      // Boss counter-attack (after player acts)
      const bossData = BOSS_STATS[session.dungeon_id];
      const bossDmg = rollDamage(bossData?.dmg || 100);
      const newMembers = [...session.members];
      newMembers[myIndex] = { ...member, hp: Math.max(0, member.hp - bossDmg) };

      const bossLogEntry = {
        text: `🐉 ${session.boss_name} retaliates for ${bossDmg} damage on ${member.name}!`,
        ts: Date.now() + 1,
        type: 'boss_attack',
        damage: bossDmg,
      };

      // Check if all players dead
      const allDead = newMembers.every(m => m.hp <= 0);
      if (allDead) {
        updates.status = 'defeat';
        updates.combat_log = [...updates.combat_log, bossLogEntry, { text: '💀 Your party has been wiped out!', ts: Date.now() + 2, type: 'defeat' }];
        updates.members = newMembers;
        const updated = await base44.entities.DungeonSession.update(sessionId, updates);
        return Response.json({ success: true, session: updated });
      }

      // Advance turn to next living player
      let nextIndex = (myIndex + 1) % newMembers.length;
      let tries = 0;
      while (newMembers[nextIndex].hp <= 0 && tries < newMembers.length) {
        nextIndex = (nextIndex + 1) % newMembers.length;
        tries++;
      }

      updates.members = newMembers;
      updates.current_turn_index = nextIndex;
      updates.turn_deadline = new Date(Date.now() + 8000).toISOString();
      updates.combat_log = [...updates.combat_log, bossLogEntry];

      const updated = await base44.entities.DungeonSession.update(sessionId, updates);
      return Response.json({ success: true, session: updated });
    }

    // ── LEAVE ─────────────────────────────────────────────────────────────────
    if (action === 'leave') {
      const session = await base44.entities.DungeonSession.get(sessionId);
      if (!session) return Response.json({ success: true });

      const remaining = (session.members || []).filter(m => m.character_id !== characterId);
      if (remaining.length === 0) {
        await base44.entities.DungeonSession.update(sessionId, { status: 'defeat', members: [] });
      } else {
        const newLeader = session.leader_id === characterId ? remaining[0].character_id : session.leader_id;
        await base44.entities.DungeonSession.update(sessionId, { members: remaining, leader_id: newLeader });
      }
      return Response.json({ success: true });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    console.error('Dungeon error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});