import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { itemId } = await req.json();

    const item = await base44.entities.Item.filter({ id: itemId }).then(items => items[0]);
    const character = await base44.entities.Character.filter({ created_by: user.email }).then(chars => chars[0]);

    if (!item || !character) {
      return Response.json({ error: 'Item or character not found' }, { status: 404 });
    }

    const currentLevel = item.upgrade_level || 0;
    if (currentLevel >= 20) {
      return Response.json({ error: 'Item at max upgrade level (20)' }, { status: 400 });
    }

    const rarityMultipliers = {
      common: 1.0, uncommon: 1.3, rare: 1.7, epic: 2.2,
      legendary: 3.0, mythic: 4.0, set: 3.5, shiny: 5.0
    };
    const rarityMult = rarityMultipliers[item.rarity] || 1.0;

    // Gold-only cost: 300g * (level + 1) * rarity multiplier
    const goldCost = Math.floor(300 * (currentLevel + 1) * rarityMult);

    if ((character.gold || 0) < goldCost) {
      return Response.json({
        error: 'Not enough gold',
        required: goldCost,
        current: character.gold || 0
      }, { status: 400 });
    }

    // Deduct gold only
    await base44.entities.Character.update(character.id, {
      gold: character.gold - goldCost
    });

    // Stat scaling: each level adds a flat +1% of BASE stat value
    // e.g. after +5 upgrades, stats are base * 1.05
    const newLevel = currentLevel + 1;
    const oldStats = item.stats || {};
    const upgradedStats = {};

    // We need base stats (before any upgrades). Since stats are mutated each upgrade,
    // reverse-calculate base: current_stat / (1 + currentLevel * 0.01)
    for (const [stat, value] of Object.entries(oldStats)) {
      const baseVal = value / (1 + currentLevel * 0.01);
      upgradedStats[stat] = Math.round(baseVal * (1 + newLevel * 0.01));
    }

    await base44.entities.Item.update(item.id, {
      upgrade_level: newLevel,
      stats: upgradedStats
    });

    return Response.json({
      success: true,
      itemName: item.name,
      newLevel,
      goldSpent: goldCost,
      oldStats,
      newStats: upgradedStats,
      message: `Upgraded to +${newLevel}! All stats +1% per level (total +${newLevel}%)`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});