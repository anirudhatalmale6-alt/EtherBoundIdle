import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Fetch all items
    const allItems = await base44.asServiceRole.entities.Item.list();
    const itemsWithStats = allItems.filter(item => item.stats && Object.keys(item.stats).length > 0);

    if (itemsWithStats.length === 0) {
      return Response.json({ updated: 0, message: 'No items with stats found' });
    }

    // Reduce all stats to 60% of original (40% nerf)
    const updates = itemsWithStats.map(item => {
      const nerfedStats = {};
      for (const [stat, value] of Object.entries(item.stats)) {
        nerfedStats[stat] = Math.max(0, Math.round(value * 0.6));
      }
      return base44.asServiceRole.entities.Item.update(item.id, { stats: nerfedStats });
    });

    await Promise.all(updates);

    return Response.json({
      updated: itemsWithStats.length,
      message: `Nerfed stats on ${itemsWithStats.length} items (reduced to 60% of original)`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});