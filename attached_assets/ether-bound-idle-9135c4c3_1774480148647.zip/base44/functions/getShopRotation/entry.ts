import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const ITEM_POOLS = {
  common: [
    { name: 'Iron Sword', type: 'weapon', rarity: 'common', stats: { damage: 8, strength: 2 } },
    { name: 'Leather Armor', type: 'armor', rarity: 'common', stats: { defense: 6, vitality: 2 } },
    { name: 'Wood Shield', type: 'armor', rarity: 'common', stats: { defense: 4, block_chance: 3 } },
    { name: 'Traveler Boots', type: 'boots', rarity: 'common', stats: { dexterity: 3, evasion: 2 } },
    { name: 'Copper Ring', type: 'ring', rarity: 'common', stats: { luck: 3 } },
    { name: 'Minor Health Potion', type: 'consumable', rarity: 'common', stats: { hp_bonus: 50 } },
  ],
  uncommon: [
    { name: 'Steel Longsword', type: 'weapon', rarity: 'uncommon', stats: { damage: 18, strength: 5 } },
    { name: 'Chainmail Vest', type: 'armor', rarity: 'uncommon', stats: { defense: 14, vitality: 5 } },
    { name: 'Hunter Bow', type: 'weapon', rarity: 'uncommon', stats: { damage: 15, dexterity: 6 } },
    { name: 'Silver Amulet', type: 'amulet', rarity: 'uncommon', stats: { intelligence: 6, mp_bonus: 30 } },
    { name: 'Swift Boots', type: 'boots', rarity: 'uncommon', stats: { dexterity: 7, evasion: 4 } },
    { name: 'Health Potion', type: 'consumable', rarity: 'uncommon', stats: { hp_bonus: 120 } },
  ],
  rare: [
    { name: 'Mithril Blade', type: 'weapon', rarity: 'rare', stats: { damage: 35, strength: 10, crit_chance: 5 } },
    { name: 'Arcane Robe', type: 'armor', rarity: 'rare', stats: { defense: 20, intelligence: 12, mp_bonus: 50 } },
    { name: 'Shadow Dagger', type: 'weapon', rarity: 'rare', stats: { damage: 28, dexterity: 12, crit_chance: 8 } },
    { name: 'Mystic Crown', type: 'helmet', rarity: 'rare', stats: { intelligence: 15, mp_bonus: 60 } },
    { name: 'EXP Scroll', type: 'consumable', rarity: 'rare', stats: { exp_gain_pct: 25 }, description: '+25% EXP for 1 hour' },
    { name: 'Gold Scroll', type: 'consumable', rarity: 'rare', stats: { gold_gain_pct: 25 }, description: '+25% Gold for 1 hour' },
  ],
  epic: [
    { name: 'Dragonbone Sword', type: 'weapon', rarity: 'epic', stats: { damage: 65, strength: 20, crit_chance: 10 } },
    { name: 'Void Plate', type: 'armor', rarity: 'epic', stats: { defense: 50, vitality: 25, hp_bonus: 200 } },
    { name: 'Storm Bow', type: 'weapon', rarity: 'epic', stats: { damage: 58, dexterity: 22, crit_chance: 12 } },
    { name: 'Sorcerer Crown', type: 'helmet', rarity: 'epic', stats: { intelligence: 28, mp_bonus: 120 } },
  ],
};

const RARITY_PRICES = { common: 500, uncommon: 1500, rare: 5000, epic: 20000 };

function generateRotation(playerLevel) {
  const items = [];
  // Always 2 common, 2 uncommon, 1 rare, chance of epic at high level
  const picks = [
    ...shuffle(ITEM_POOLS.common).slice(0, 2),
    ...shuffle(ITEM_POOLS.uncommon).slice(0, 2),
    ...shuffle(ITEM_POOLS.rare).slice(0, 1),
  ];
  if (playerLevel >= 20) picks.push(...shuffle(ITEM_POOLS.epic).slice(0, 1));

  return picks.map(item => ({
    ...item,
    buy_price: Math.floor(RARITY_PRICES[item.rarity] * (1 + (playerLevel - 1) * 0.05)),
    sell_price: Math.floor(RARITY_PRICES[item.rarity] * 0.3),
    item_level: Math.max(1, playerLevel - 2 + Math.floor(Math.random() * 4)),
  }));
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { characterId, forceRefresh } = await req.json();
    const character = await base44.entities.Character.get(characterId);
    if (!character) return Response.json({ error: 'Character not found' }, { status: 404 });

    const rotations = await base44.asServiceRole.entities.ShopRotation.list();
    const rotation = rotations[0];
    const now = new Date();
    const fourHours = 4 * 60 * 60 * 1000;

    if (!forceRefresh && rotation && new Date(rotation.next_refresh_at) > now) {
      return Response.json({ success: true, items: rotation.items, nextRefreshAt: rotation.next_refresh_at });
    }

    const items = generateRotation(character.level || 1);
    const nextRefresh = new Date(now.getTime() + fourHours);

    if (rotation) {
      await base44.asServiceRole.entities.ShopRotation.update(rotation.id, {
        items, refreshed_at: now.toISOString(), next_refresh_at: nextRefresh.toISOString()
      });
    } else {
      await base44.asServiceRole.entities.ShopRotation.create({
        items, refreshed_at: now.toISOString(), next_refresh_at: nextRefresh.toISOString()
      });
    }

    return Response.json({ success: true, items, nextRefreshAt: nextRefresh.toISOString() });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});