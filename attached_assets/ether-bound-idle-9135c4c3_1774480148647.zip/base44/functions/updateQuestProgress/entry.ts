import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// Update quest progress based on action
// Called from: Battle (kills), LifeSkills (gathering), etc.

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user?.email) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { characterId, objectiveType, targetResource, amount = 1 } = body;

    if (!characterId || !objectiveType) {
      return Response.json({ error: 'characterId and objectiveType required' }, { status: 400 });
    }

    const character = await base44.entities.Character.filter({ id: characterId });
    if (!character[0] || character[0].created_by !== user.email) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Get all active quests for this character
    const quests = await base44.entities.Quest.filter({
      character_id: characterId,
      status: 'active',
    });

    const updated = [];

    for (const quest of quests) {
      // Check if quest matches this objective type
      if (quest.objective_type !== objectiveType) continue;

      // For life skills: check resource type
      if (['mining', 'fishing', 'herbalism'].includes(objectiveType)) {
        if (quest.target_resource !== targetResource && quest.target_resource !== 'any') continue;
      }

      // For combat: check enemy type (or 'any' for generic kills)
      if (objectiveType === 'combat_kills') {
        if (quest.target_resource !== targetResource && quest.target_resource !== 'any') continue;
      }

      // Update progress
      const newCount = Math.min((quest.current_count || 0) + amount, quest.target_count);
      const newStatus = newCount >= quest.target_count ? 'completed' : 'active';

      const updatedQuest = await base44.entities.Quest.update(quest.id, {
        current_count: newCount,
        status: newStatus,
      });

      updated.push({
        id: quest.id,
        title: quest.title,
        current_count: newCount,
        target_count: quest.target_count,
        status: newStatus,
      });
    }

    return Response.json({
      success: true,
      updated: updated.length,
      quests: updated,
    });
  } catch (error) {
    console.error('Quest progress update error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});