import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { action, characterId, targetCharacterId, targetName, partyId } = body;

    if (!characterId) return Response.json({ error: 'characterId required' }, { status: 400 });

    const character = await base44.entities.Character.get(characterId);
    if (!character) return Response.json({ error: 'Character not found' }, { status: 404 });

    // ── CREATE ────────────────────────────────────────────────────────────────
    if (action === 'create') {
      // Disband any existing active party first
      const existing = await base44.entities.Party.filter({ leader_id: characterId });
      for (const p of existing) {
        if (p.status !== 'disbanded') {
          await base44.entities.Party.update(p.id, { status: 'disbanded' });
        }
      }
      const party = await base44.entities.Party.create({
        leader_id: characterId,
        leader_name: character.name,
        members: [{ character_id: characterId, name: character.name, class: character.class, level: character.level, status: 'online' }],
        status: 'forming',
        max_size: 6,
      });
      return Response.json({ success: true, party });
    }

    // ── INVITE ────────────────────────────────────────────────────────────────
    if (action === 'invite') {
      if (!partyId) return Response.json({ error: 'partyId required' }, { status: 400 });

      const party = await base44.entities.Party.get(partyId);
      if (!party) return Response.json({ error: 'Party not found' }, { status: 404 });
      if ((party.members || []).length >= (party.max_size || 6)) {
        return Response.json({ error: 'Party is full' }, { status: 400 });
      }

      // Look up target by ID first, then by name
      let target = null;
      if (targetCharacterId) {
        try { target = await base44.entities.Character.get(targetCharacterId); } catch {}
      }
      if (!target && targetName) {
        const results = await base44.entities.Character.filter({ name: targetName });
        target = results[0] || null;
      }
      // If inviteTarget looks like a name (not a UUID), search by name
      if (!target && targetCharacterId && !targetCharacterId.includes('-')) {
        const results = await base44.entities.Character.filter({ name: targetCharacterId });
        target = results[0] || null;
      }
      if (!target) return Response.json({ error: 'Target character not found' }, { status: 404 });

      // Check not already in party
      if ((party.members || []).some(m => m.character_id === target.id)) {
        return Response.json({ error: 'Player already in party' }, { status: 400 });
      }

      const expires = new Date(Date.now() + 5 * 60 * 1000);
      const invite = await base44.entities.PartyInvite.create({
        party_id: partyId,
        from_character_id: characterId,
        from_name: character.name,
        to_character_id: target.id,
        status: 'pending',
        expires_at: expires.toISOString(),
      });
      return Response.json({ success: true, invite });
    }

    // ── ACCEPT ────────────────────────────────────────────────────────────────
    if (action === 'accept') {
      if (!body.inviteId) return Response.json({ error: 'inviteId required' }, { status: 400 });

      const invite = await base44.entities.PartyInvite.get(body.inviteId);
      if (!invite || invite.status !== 'pending') {
        return Response.json({ error: 'Invite not found or expired' }, { status: 404 });
      }
      const party = await base44.entities.Party.get(invite.party_id);
      if (!party) return Response.json({ error: 'Party no longer exists' }, { status: 404 });

      // Check not already in party
      if ((party.members || []).some(m => m.character_id === characterId)) {
        await base44.entities.PartyInvite.update(invite.id, { status: 'accepted' });
        return Response.json({ success: true });
      }

      const newMember = { character_id: characterId, name: character.name, class: character.class, level: character.level, status: 'online' };
      const updatedParty = await base44.entities.Party.update(party.id, {
        members: [...(party.members || []), newMember],
        status: 'active',
      });
      await base44.entities.PartyInvite.update(invite.id, { status: 'accepted' });
      return Response.json({ success: true, party: updatedParty });
    }

    // ── DECLINE ───────────────────────────────────────────────────────────────
    if (action === 'decline') {
      if (!body.inviteId) return Response.json({ error: 'inviteId required' }, { status: 400 });
      await base44.entities.PartyInvite.update(body.inviteId, { status: 'declined' });
      return Response.json({ success: true });
    }

    // ── LEAVE ─────────────────────────────────────────────────────────────────
    if (action === 'leave') {
      if (!partyId) return Response.json({ error: 'partyId required' }, { status: 400 });

      const party = await base44.entities.Party.get(partyId);
      if (!party) return Response.json({ success: true }); // already gone

      const remaining = (party.members || []).filter(m => m.character_id !== characterId);
      if (remaining.length === 0) {
        await base44.entities.Party.update(partyId, { status: 'disbanded', members: [] });
      } else if (party.leader_id === characterId) {
        const newLeader = remaining[0];
        await base44.entities.Party.update(partyId, {
          members: remaining,
          leader_id: newLeader.character_id,
          leader_name: newLeader.name,
        });
      } else {
        await base44.entities.Party.update(partyId, { members: remaining });
      }
      return Response.json({ success: true });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    console.error('manageParty error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});