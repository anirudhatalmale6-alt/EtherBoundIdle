import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || (user.role !== 'admin' && user.role !== 'superadmin')) {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { action, target_character_id, data } = await req.json();

    if (!action || !target_character_id) {
      return Response.json({ error: 'action and target_character_id required' }, { status: 400 });
    }

    // Get target character
    const targetChar = await base44.asServiceRole.entities.Character.filter({ id: target_character_id });
    if (!targetChar || targetChar.length === 0) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    const character = targetChar[0];

    switch (action) {
      case 'ban':
        const banned = await base44.asServiceRole.entities.Character.update(target_character_id, { is_banned: true });
        console.log(`[ADMIN] ${user.email} banned character ${character.name}`);
        return Response.json({ success: true, message: `${character.name} has been banned`, data: banned });

      case 'unban':
        const unbanned = await base44.asServiceRole.entities.Character.update(target_character_id, { is_banned: false });
        console.log(`[ADMIN] ${user.email} unbanned character ${character.name}`);
        return Response.json({ success: true, message: `${character.name} has been unbanned`, data: unbanned });

      case 'mute':
        await base44.asServiceRole.entities.Character.update(target_character_id, { is_muted: true, muted_until: new Date(Date.now() + (data?.hours || 24) * 60 * 60 * 1000).toISOString() });
        console.log(`[ADMIN] ${user.email} muted character ${character.name}`);
        return Response.json({ success: true, message: `${character.name} has been muted for ${data?.hours || 24} hours` });

      case 'unmute':
        await base44.asServiceRole.entities.Character.update(target_character_id, { is_muted: false });
        console.log(`[ADMIN] ${user.email} unmuted character ${character.name}`);
        return Response.json({ success: true, message: `${character.name} has been unmuted` });

      case 'update_stats':
        const updates = {};
        if (data?.level !== undefined) updates.level = data.level;
        if (data?.gold !== undefined) updates.gold = data.gold;
        if (data?.gems !== undefined) updates.gems = data.gems;
        if (data?.exp !== undefined) updates.exp = data.exp;
        if (data?.hp !== undefined) updates.hp = data.hp;
        if (data?.max_hp !== undefined) updates.max_hp = data.max_hp;
        if (data?.mp !== undefined) updates.mp = data.mp;
        if (data?.max_mp !== undefined) updates.max_mp = data.max_mp;
        if (data?.strength !== undefined) updates.strength = data.strength;
        if (data?.dexterity !== undefined) updates.dexterity = data.dexterity;
        if (data?.intelligence !== undefined) updates.intelligence = data.intelligence;
        if (data?.vitality !== undefined) updates.vitality = data.vitality;
        if (data?.luck !== undefined) updates.luck = data.luck;
        if (data?.stat_points !== undefined) updates.stat_points = data.stat_points;
        if (data?.skill_points !== undefined) updates.skill_points = data.skill_points;
        
        const updated = await base44.asServiceRole.entities.Character.update(target_character_id, updates);
        console.log(`[ADMIN] ${user.email} updated stats for ${character.name}:`, updates);
        return Response.json({ success: true, message: 'Character stats updated', data: updated });

      case 'delete':
        await base44.asServiceRole.entities.Character.delete(target_character_id);
        console.log(`[ADMIN] ${user.email} deleted character ${character.name}`);
        return Response.json({ success: true, message: `${character.name} has been deleted` });

      case 'delete_from_leaderboard':
        const removedRank = await base44.asServiceRole.entities.Character.update(target_character_id, { deleted_from_leaderboard: true });
        console.log(`[ADMIN] ${user.email} removed ${character.name} from leaderboard`);
        return Response.json({ success: true, message: `${character.name} removed from leaderboard`, data: removedRank });

      case 'restore_leaderboard':
        const restoredRank = await base44.asServiceRole.entities.Character.update(target_character_id, { deleted_from_leaderboard: false });
        console.log(`[ADMIN] ${user.email} restored ${character.name} to leaderboard`);
        return Response.json({ success: true, message: `${character.name} restored to leaderboard`, data: restoredRank });

      default:
        return Response.json({ error: 'Unknown action' }, { status: 400 });
    }
  } catch (error) {
    console.error('Manage player error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});