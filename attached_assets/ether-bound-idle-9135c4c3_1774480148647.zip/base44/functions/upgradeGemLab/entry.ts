import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * Upgrade a Gem Lab component (production, speed, or efficiency)
 * Uses exponential cost scaling
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { characterId, upgradeType } = await req.json();
    if (!characterId || !upgradeType) {
      return Response.json({ error: 'Missing parameters' }, { status: 400 });
    }

    if (!['production', 'speed', 'efficiency'].includes(upgradeType)) {
      return Response.json({ error: 'Invalid upgrade type' }, { status: 400 });
    }

    // Get character
    const character = await base44.entities.Character.get(characterId);
    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Get GemLab
    const labs = await base44.entities.GemLab.filter({ character_id: characterId });
    let lab = labs[0];

    if (!lab) {
      lab = await base44.entities.GemLab.create({
        character_id: characterId,
        last_collection_time: new Date().toISOString(),
      });
    }

    // ===== COST CALCULATION =====
    // Exponential scaling: cost = baseCost * (1.15 ^ level)
    const BASE_COST = 1000;
    const COST_MULTIPLIER = 1.15;

    const levelKey = `${upgradeType}_level`;
    const currentLevel = lab[levelKey] || 0;
    const upgradeCost = Math.floor(BASE_COST * Math.pow(COST_MULTIPLIER, currentLevel));

    // ===== VALIDATION =====
    if ((character.gold || 0) < upgradeCost) {
      return Response.json({
        error: `Insufficient gold. Need ${upgradeCost}, have ${character.gold}`,
        required: upgradeCost,
        current: character.gold,
      }, { status: 400 });
    }

    // ===== UPGRADE =====
    const newLevel = currentLevel + 1;
    const updates = {
      [levelKey]: newLevel,
    };

    // Deduct gold from character
    const newGold = character.gold - upgradeCost;

    await Promise.all([
      base44.entities.GemLab.update(lab.id, updates),
      base44.entities.Character.update(characterId, { gold: newGold }),
    ]);

    // Calculate preview of new production
    const productionMult = 1 + (newLevel * 0.05);
    const speedMult = 1 + (newLevel * 0.02);
    const efficiencyMult = 1 + (newLevel * 0.03);

    return Response.json({
      success: true,
      upgradeType,
      newLevel,
      costPaid: upgradeCost,
      goldRemaining: newGold,
      nextUpgradeCost: Math.floor(BASE_COST * Math.pow(COST_MULTIPLIER, newLevel)),
      productionMultiplier: productionMult,
      speedMultiplier: speedMult,
      efficiencyMultiplier: efficiencyMult,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});