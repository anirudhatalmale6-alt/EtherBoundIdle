import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * Server-side item selling function
 * Validates item ownership, calculates sell price, updates inventory and gold
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { itemId } = await req.json();

    if (!itemId) {
      return Response.json({ error: 'Missing itemId' }, { status: 400 });
    }

    // Fetch the item by filtering
    const items = await base44.entities.Item.filter({ id: itemId });
    const item = items[0];
    if (!item) {
      return Response.json({ error: 'Item not found' }, { status: 404 });
    }

    // Verify ownership (item owner_id should match character owner)
    const characters = await base44.entities.Character.filter({ created_by: user.email });
    const character = characters[0];
    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }
    if (item.owner_id !== character.id) {
      return Response.json({ error: 'Item does not belong to you' }, { status: 403 });
    }

    const sellPrice = item.sell_price || 5;

    // Unequip item if equipped
    if (item.equipped) {
      const slot = item.type;
      const equipment = { ...(character.equipment || {}) };
      delete equipment[slot];
      await base44.entities.Character.update(character.id, { equipment });
    }

    // Delete the item
    await base44.entities.Item.delete(itemId);

    // Update gold
    const newGold = (character.gold || 0) + sellPrice;
    await base44.entities.Character.update(character.id, { gold: newGold });

    return Response.json({
      success: true,
      sellPrice,
      newGold,
      itemId,
    });
  } catch (error) {
    console.error('Sell error:', error);
    return Response.json({ error: 'Server error: ' + error.message }, { status: 500 });
  }
});