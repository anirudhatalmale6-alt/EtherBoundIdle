import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// Generate/reset daily quests for a character
// Called on login or via automation

const DAILY_QUEST_TEMPLATES = [
  // Mining quests
  { objective_type: 'mining', target_resource: 'iron_ore', target_count: 15, reward_gold: 100, reward_exp: 200 },
  { objective_type: 'mining', target_resource: 'copper_ore', target_count: 12, reward_gold: 120, reward_exp: 220 },
  { objective_type: 'mining', target_resource: 'silver_ore', target_count: 8, reward_gold: 150, reward_exp: 250 },
  { objective_type: 'mining', target_resource: 'gold_ore', target_count: 5, reward_gold: 200, reward_exp: 300 },

  // Fishing quests
  { objective_type: 'fishing', target_resource: 'carp', target_count: 20, reward_gold: 90, reward_exp: 180 },
  { objective_type: 'fishing', target_resource: 'salmon', target_count: 15, reward_gold: 120, reward_exp: 240 },
  { objective_type: 'fishing', target_resource: 'tuna', target_count: 10, reward_gold: 150, reward_exp: 280 },
  { objective_type: 'fishing', target_resource: 'swordfish', target_count: 5, reward_gold: 200, reward_exp: 350 },

  // Herbalism quests
  { objective_type: 'herbalism', target_resource: 'common_herb', target_count: 25, reward_gold: 80, reward_exp: 160 },
  { objective_type: 'herbalism', target_resource: 'greenleaf', target_count: 18, reward_gold: 110, reward_exp: 220 },
  { objective_type: 'herbalism', target_resource: 'blue_herb', target_count: 10, reward_gold: 140, reward_exp: 260 },
  { objective_type: 'herbalism', target_resource: 'shadow_herb', target_count: 6, reward_gold: 180, reward_exp: 320 },

  // Combat quests
  { objective_type: 'combat_kills', target_resource: 'any', target_count: 20, reward_gold: 150, reward_exp: 300 },
  { objective_type: 'combat_kills', target_resource: 'goblin', target_count: 15, reward_gold: 120, reward_exp: 250 },
  { objective_type: 'combat_kills', target_resource: 'orc', target_count: 10, reward_gold: 160, reward_exp: 320 },
  { objective_type: 'combat_damage', target_resource: 'any', target_count: 500, reward_gold: 180, reward_exp: 350 },
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user?.email) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { characterId } = body;

    if (!characterId) {
      return Response.json({ error: 'characterId required' }, { status: 400 });
    }

    const character = await base44.entities.Character.filter({ id: characterId });
    if (!character[0] || character[0].created_by !== user.email) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

    // Get all daily quests for this character
    const existingDailyQuests = await base44.entities.Quest.filter({
      character_id: characterId,
      is_daily: true,
    });

    const quests = [];

    // Check if we need to reset (past date or no quests)
    const needsReset = existingDailyQuests.length === 0 ||
      (existingDailyQuests[0].daily_reset_date && existingDailyQuests[0].daily_reset_date !== today);

    if (needsReset) {
      // Delete old daily quests
      for (const q of existingDailyQuests) {
        if (q.status !== 'claimed') {
          await base44.entities.Quest.delete(q.id).catch(() => {});
        }
      }

      // Generate 3-5 random daily quests
      const questCount = 3 + Math.floor(Math.random() * 3);
      const selected = [];
      for (let i = 0; i < questCount; i++) {
        const template = DAILY_QUEST_TEMPLATES[Math.floor(Math.random() * DAILY_QUEST_TEMPLATES.length)];
        selected.push(template);
      }

      // Create new daily quests
      for (const template of selected) {
        const questTitle = `[Daily] ${template.target_resource === 'any'
          ? `Defeat ${template.target_count} enemies`
          : `Collect ${template.target_count} ${template.target_resource}`
        }`;

        const created = await base44.entities.Quest.create({
          title: questTitle,
          description: `Complete this daily objective before reset.`,
          type: 'daily',
          objective_type: template.objective_type,
          target_resource: template.target_resource,
          target_count: template.target_count,
          current_count: 0,
          character_id: characterId,
          status: 'active',
          is_daily: true,
          daily_reset_date: today,
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          rewards: {
            exp: template.reward_exp,
            gold: template.reward_gold,
            gems: Math.floor(template.reward_exp / 50),
          },
        });

        quests.push(created);
      }
    } else {
      quests.push(...existingDailyQuests);
    }

    return Response.json({
      success: true,
      generated: needsReset,
      daily_reset_date: today,
      quests: quests.map(q => ({
        id: q.id,
        title: q.title,
        objective_type: q.objective_type,
        target_resource: q.target_resource,
        target_count: q.target_count,
        current_count: q.current_count,
        status: q.status,
      })),
    });
  } catch (error) {
    console.error('Daily quest management error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});