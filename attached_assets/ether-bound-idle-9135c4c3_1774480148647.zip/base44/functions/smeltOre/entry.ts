import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { characterId, oreType, quantity } = await req.json();

    // Fetch character and validate ownership
    const character = await base44.entities.Character.filter({
      id: characterId,
      created_by: user.email
    }).then(chars => chars[0]);

    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Define smelting recipes: oreType -> barType (5 ore = 1 bar)
    const smeltingRecipes = {
      iron_ore: { barType: 'iron_bar', oreToBar: 5 },
      copper_ore: { barType: 'copper_bar', oreToBar: 5 },
      silver_ore: { barType: 'silver_bar', oreToBar: 5 },
      gold_ore: { barType: 'gold_bar', oreToBar: 5 },
      platinum_ore: { barType: 'platinum_bar', oreToBar: 5 },
      void_ore: { barType: 'void_bar', oreToBar: 5 },
      crystal_ore: { barType: 'crystal_bar', oreToBar: 5 },
    };

    const recipe = smeltingRecipes[oreType];
    if (!recipe) {
      return Response.json({ error: 'Invalid ore type' }, { status: 400 });
    }

    // Check ore inventory
    const oreResource = await base44.entities.Resource.filter({
      character_id: characterId,
      resource_type: oreType
    }).then(r => r[0] || null);

    const availableOre = oreResource?.quantity || 0;
    if (availableOre < quantity) {
      return Response.json({
        error: `Not enough ${oreType.replace('_', ' ')}`,
        required: quantity,
        current: availableOre
      }, { status: 400 });
    }

    // Calculate bars produced
    const barsProduced = Math.floor(quantity / recipe.oreToBar);
    const oreUsed = barsProduced * recipe.oreToBar;

    if (barsProduced === 0) {
      return Response.json({
        error: `Need at least ${recipe.oreToBar} ore to produce 1 bar`,
        current: availableOre
      }, { status: 400 });
    }

    // Deduct ore
    const newOreQuantity = availableOre - oreUsed;
    if (newOreQuantity === 0) {
      await base44.entities.Resource.delete(oreResource.id);
    } else {
      await base44.entities.Resource.update(oreResource.id, {
        quantity: newOreQuantity
      });
    }

    // Add or update bar resource
    const barResource = await base44.entities.Resource.filter({
      character_id: characterId,
      resource_type: recipe.barType
    }).then(r => r[0] || null);

    if (barResource) {
      await base44.entities.Resource.update(barResource.id, {
        quantity: (barResource.quantity || 0) + barsProduced
      });
    } else {
      await base44.entities.Resource.create({
        character_id: characterId,
        resource_type: recipe.barType,
        quantity: barsProduced,
        rarity: 'common'
      });
    }

    return Response.json({
      success: true,
      oreType,
      barType: recipe.barType,
      oreUsed,
      barsProduced,
      remainingOre: newOreQuantity,
      message: `🔥 Smelted ${oreUsed} ${oreType.replace('_', ' ')} into ${barsProduced} ${recipe.barType.replace('_', ' ')}!`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});