import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

// ─────────────────────────────────────────────────────────────────────────────
// GATHERING SKILLS (base 3 only)
// ─────────────────────────────────────────────────────────────────────────────
const BASE_SKILL_TYPES = ['mining', 'fishing', 'herbalism'];

const SKILL_DROPS = {
  mining: [
    { type: "iron_ore",      label: "Iron Ore",       rarity: "common",    weight: 55, minLevel: 1  },
    { type: "copper_ore",    label: "Copper Ore",     rarity: "uncommon",  weight: 25, minLevel: 1  },
    { type: "silver_ore",    label: "Silver Ore",     rarity: "rare",      weight: 12, minLevel: 5  },
    { type: "gold_ore",      label: "Gold Ore",       rarity: "epic",      weight: 5,  minLevel: 15 },
    { type: "platinum_ore",  label: "Platinum Ore",   rarity: "legendary", weight: 2,  minLevel: 25 },
    { type: "void_ore",      label: "Void Ore",       rarity: "mythic",    weight: 0.8,minLevel: 40 },
    { type: "crystal_ore",   label: "Crystal Ore",    rarity: "shiny",     weight: 0.2,minLevel: 50 },
  ],
  fishing: [
    { type: "carp",           label: "Carp",           rarity: "common",    weight: 55, minLevel: 1  },
    { type: "salmon",         label: "Salmon",         rarity: "uncommon",  weight: 25, minLevel: 1  },
    { type: "tuna",           label: "Tuna",           rarity: "rare",      weight: 12, minLevel: 5  },
    { type: "swordfish",      label: "Swordfish",      rarity: "epic",      weight: 5,  minLevel: 15 },
    { type: "dragonfish",     label: "Dragonfish",     rarity: "legendary", weight: 2,  minLevel: 25 },
    { type: "leviathan_fish", label: "Leviathan Fish", rarity: "mythic",    weight: 0.8,minLevel: 40 },
    { type: "golden_fish",    label: "Golden Fish",    rarity: "shiny",     weight: 0.2,minLevel: 50 },
  ],
  herbalism: [
    { type: "common_herb",  label: "Common Herb",    rarity: "common",    weight: 55, minLevel: 1  },
    { type: "greenleaf",    label: "Greenleaf",      rarity: "uncommon",  weight: 25, minLevel: 1  },
    { type: "blue_herb",    label: "Blue Herb",      rarity: "rare",      weight: 12, minLevel: 5  },
    { type: "shadow_herb",  label: "Shadow Herb",    rarity: "epic",      weight: 5,  minLevel: 15 },
    { type: "sun_blossom",  label: "Sun Blossom",    rarity: "legendary", weight: 2,  minLevel: 25 },
    { type: "ether_plant",  label: "Ether Plant",    rarity: "mythic",    weight: 0.8,minLevel: 40 },
    { type: "spirit_herb",  label: "Spirit Herb",    rarity: "shiny",     weight: 0.2,minLevel: 50 },
  ],
};

// ─────────────────────────────────────────────────────────────────────────────
// PROCESSING RECIPES (smelting / cooking / alchemy)
// Unlocked when base skill reaches level 30.
// Each recipe: input resource -> output resource, same rarity
// ─────────────────────────────────────────────────────────────────────────────
const PROCESSING_RECIPES = {
  smelting: {
    requires_skill: 'mining',
    requires_level: 30,
    label: 'Smelting',
    icon: '🔥',
    description: 'Smelt ores into refined bars',
    recipes: [
      { input: 'iron_ore',     output: 'iron_bar',     output_label: 'Iron Bar',     input_label: 'Iron Ore',     rarity: 'common'    },
      { input: 'copper_ore',   output: 'copper_bar',   output_label: 'Copper Bar',   input_label: 'Copper Ore',   rarity: 'uncommon'  },
      { input: 'silver_ore',   output: 'silver_bar',   output_label: 'Silver Bar',   input_label: 'Silver Ore',   rarity: 'rare'      },
      { input: 'gold_ore',     output: 'gold_bar',     output_label: 'Gold Bar',     input_label: 'Gold Ore',     rarity: 'epic'      },
      { input: 'platinum_ore', output: 'platinum_bar', output_label: 'Platinum Bar', input_label: 'Platinum Ore', rarity: 'legendary' },
      { input: 'void_ore',     output: 'void_bar',     output_label: 'Void Bar',     input_label: 'Void Ore',     rarity: 'mythic'    },
      { input: 'crystal_ore',  output: 'crystal_bar',  output_label: 'Crystal Bar',  input_label: 'Crystal Ore',  rarity: 'shiny'     },
    ],
  },
  cooking: {
    requires_skill: 'fishing',
    requires_level: 30,
    label: 'Cooking',
    icon: '🍳',
    description: 'Cook fish into hearty meals',
    recipes: [
      { input: 'carp',           output: 'grilled_carp',    output_label: 'Grilled Carp',    input_label: 'Carp',           rarity: 'common'    },
      { input: 'salmon',         output: 'salmon_steak',    output_label: 'Salmon Steak',    input_label: 'Salmon',         rarity: 'uncommon'  },
      { input: 'tuna',           output: 'tuna_soup',       output_label: 'Tuna Soup',       input_label: 'Tuna',           rarity: 'rare'      },
      { input: 'swordfish',      output: 'swordfish_feast', output_label: 'Swordfish Feast', input_label: 'Swordfish',      rarity: 'epic'      },
      { input: 'dragonfish',     output: 'dragon_broth',    output_label: 'Dragon Broth',    input_label: 'Dragonfish',     rarity: 'legendary' },
      { input: 'leviathan_fish', output: 'leviathan_stew',  output_label: 'Leviathan Stew',  input_label: 'Leviathan Fish', rarity: 'mythic'    },
      { input: 'golden_fish',    output: 'golden_banquet',  output_label: 'Golden Banquet',  input_label: 'Golden Fish',    rarity: 'shiny'     },
    ],
  },
  alchemy: {
    requires_skill: 'herbalism',
    requires_level: 30,
    label: 'Alchemy',
    icon: '⚗️',
    description: 'Brew herbs into powerful potions',
    recipes: [
      { input: 'common_herb',  output: 'minor_potion',   output_label: 'Minor Potion',   input_label: 'Common Herb',  rarity: 'common'    },
      { input: 'greenleaf',    output: 'healing_salve',  output_label: 'Healing Salve',  input_label: 'Greenleaf',    rarity: 'uncommon'  },
      { input: 'blue_herb',    output: 'mana_elixir',    output_label: 'Mana Elixir',    input_label: 'Blue Herb',    rarity: 'rare'      },
      { input: 'shadow_herb',  output: 'strength_brew',  output_label: 'Strength Brew',  input_label: 'Shadow Herb',  rarity: 'epic'      },
      { input: 'sun_blossom',  output: 'sun_tincture',   output_label: 'Sun Tincture',   input_label: 'Sun Blossom',  rarity: 'legendary' },
      { input: 'ether_plant',  output: 'ether_draught',  output_label: 'Ether Draught',  input_label: 'Ether Plant',  rarity: 'mythic'    },
      { input: 'spirit_herb',  output: 'spirit_essence', output_label: 'Spirit Essence', input_label: 'Spirit Herb',  rarity: 'shiny'     },
    ],
  },
};

const XP_PER_CYCLE       = { mining: 15, fishing: 12, herbalism: 10 };
const BASE_CYCLE_SECONDS = { mining: 20, fishing: 18, herbalism: 15 };

function xpToNextLevel(level) {
  return Math.floor(100 * Math.pow(1.35, level - 1));
}
function cycleDuration(skillType, speedLevel) {
  const base = BASE_CYCLE_SECONDS[skillType] || 20;
  return base * Math.pow(0.92, speedLevel - 1);
}
function speedUpgradeCost(lvl) { return Math.floor(50 * Math.pow(2.2, lvl - 1)); }
function luckUpgradeCost(lvl)  { return Math.floor(80 * Math.pow(2.5, lvl - 1)); }

function rollDrop(skillType, skillLevel, luckLevel) {
  const table = SKILL_DROPS[skillType] || SKILL_DROPS.mining;
  const luckBoost = 1 + (luckLevel - 1) * 0.15;
  const available = table.filter(e => skillLevel >= e.minLevel);
  const weighted = available.map(e => ({
    ...e,
    effectiveWeight: e.rarity === "common" ? e.weight : e.weight * luckBoost
  }));
  const total = weighted.reduce((s, e) => s + e.effectiveWeight, 0);
  let roll = Math.random() * total;
  for (const e of weighted) {
    roll -= e.effectiveWeight;
    if (roll <= 0) return e;
  }
  return weighted[0];
}

async function getOrCreateSkill(base44, characterId, skillType) {
  const existing = await base44.asServiceRole.entities.LifeSkill.filter({ character_id: characterId, skill_type: skillType });
  if (existing.length > 0) return existing[0];
  return await base44.asServiceRole.entities.LifeSkill.create({
    character_id: characterId,
    skill_type: skillType,
    level: 1, exp: 0,
    exp_to_next: xpToNextLevel(1),
    gather_progress: 0,
    is_active: false,
    speed_level: 1,
    luck_level: 1,
  });
}

async function getOrCreateResource(base44, characterId, resourceType, rarity) {
  const existing = await base44.asServiceRole.entities.Resource.filter({
    character_id: characterId,
    resource_type: resourceType,
    rarity: rarity,
  });
  if (existing.length > 0) return existing[0];
  return await base44.asServiceRole.entities.Resource.create({
    character_id: characterId,
    resource_type: resourceType,
    rarity: rarity,
    quantity: 0,
  });
}

function enrichSkill(skill, skillType) {
  const speedLvl = skill.speed_level || 1;
  const luckLvl  = skill.luck_level  || 1;
  return {
    ...skill,
    cycle_duration: cycleDuration(skillType, speedLvl),
    xp_per_cycle: XP_PER_CYCLE[skillType] || 15,
    speed_upgrade_cost: speedUpgradeCost(speedLvl),
    luck_upgrade_cost: luckUpgradeCost(luckLvl),
    exp_to_next: xpToNextLevel(skill.level),
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { action, character_id, skill_type } = body;

    if (!character_id) return Response.json({ error: 'character_id required' }, { status: 400 });

    const chars = await base44.asServiceRole.entities.Character.filter({ id: character_id });
    if (!chars.length || chars[0].created_by !== user.email) {
      return Response.json({ error: 'Character not found or not yours' }, { status: 403 });
    }
    const character = chars[0];

    // ─── GET ALL SKILLS ───────────────────────────────────────────────────────
    if (action === 'get_skills') {
      // Only 3 base gathering skills
      const skills = await Promise.all(BASE_SKILL_TYPES.map(s => getOrCreateSkill(base44, character_id, s)));
      const resources = await base44.asServiceRole.entities.Resource.filter({ character_id });
      const enriched = skills.map(s => enrichSkill(s, s.skill_type));

      // Build processing unlock status
      const skillLevelMap = Object.fromEntries(skills.map(s => [s.skill_type, s.level || 1]));
      const processingStatus = {};
      for (const [key, proc] of Object.entries(PROCESSING_RECIPES)) {
        processingStatus[key] = {
          ...proc,
          is_unlocked: (skillLevelMap[proc.requires_skill] || 0) >= proc.requires_level,
        };
      }

      return Response.json({ skills: enriched, resources, processing: processingStatus });
    }

    // ─── START ────────────────────────────────────────────────────────────────
    if (action === 'start') {
      if (!skill_type || !BASE_SKILL_TYPES.includes(skill_type))
        return Response.json({ error: 'Invalid skill_type' }, { status: 400 });

      const allSkills = await base44.asServiceRole.entities.LifeSkill.filter({ character_id });
      const alreadyActive = allSkills.find(s => s.is_active && s.skill_type !== skill_type);
      if (alreadyActive) {
        return Response.json({ error: `Already gathering: ${alreadyActive.skill_type}`, active_skill: alreadyActive.skill_type }, { status: 409 });
      }

      const skill = await getOrCreateSkill(base44, character_id, skill_type);
      if (skill.is_active) return Response.json({ success: true, skill: enrichSkill(skill, skill_type) });

      const updated = await base44.asServiceRole.entities.LifeSkill.update(skill.id, {
        is_active: true,
        session_started_at: new Date().toISOString(),
        last_tick_at: new Date().toISOString(),
      });
      return Response.json({ success: true, skill: enrichSkill(updated, skill_type) });
    }

    // ─── STOP ─────────────────────────────────────────────────────────────────
    if (action === 'stop') {
      if (!skill_type) return Response.json({ error: 'skill_type required' }, { status: 400 });
      const skill = await getOrCreateSkill(base44, character_id, skill_type);
      const updated = await base44.asServiceRole.entities.LifeSkill.update(skill.id, {
        is_active: false, session_started_at: null, last_tick_at: null, gather_progress: 0,
      });
      return Response.json({ success: true, skill: updated });
    }

    // ─── TICK ─────────────────────────────────────────────────────────────────
    if (action === 'tick') {
      if (!skill_type) return Response.json({ error: 'skill_type required' }, { status: 400 });

      const skill = await getOrCreateSkill(base44, character_id, skill_type);
      if (!skill.is_active) return Response.json({ success: true, resources: [], xp_gained: 0, skill: enrichSkill(skill, skill_type) });

      const now = Date.now();
      const lastTick = skill.last_tick_at
        ? new Date(skill.last_tick_at).getTime()
        : new Date(skill.session_started_at).getTime();
      const elapsedSec = Math.min((now - lastTick) / 1000, 120);

      const speedLvl  = skill.speed_level || 1;
      const luckLvl   = skill.luck_level  || 1;
      const cycleTime = cycleDuration(skill_type, speedLvl);
      const progressGained = (elapsedSec / cycleTime) * 100;
      let totalProgress = (skill.gather_progress || 0) + progressGained;

      const resourcesGained = [];
      let totalXpGained = 0;
      let currentLevel = skill.level;
      let currentExp = skill.exp;
      let currentExpToNext = xpToNextLevel(currentLevel);
      let leveledUp = false;

      while (totalProgress >= 100) {
        totalProgress -= 100;
        const drop = rollDrop(skill_type, currentLevel, luckLvl);
        resourcesGained.push(drop);
        const xpGain = XP_PER_CYCLE[skill_type] || 15;
        totalXpGained += xpGain;
        currentExp += xpGain;
        while (currentExp >= currentExpToNext) {
          currentExp -= currentExpToNext;
          currentLevel += 1;
          currentExpToNext = xpToNextLevel(currentLevel);
          leveledUp = true;
        }
      }

      const resourceResults = [];
      for (const drop of resourcesGained) {
        const res = await getOrCreateResource(base44, character_id, drop.type, drop.rarity);
        const newQty = Math.min((res.quantity || 0) + 1, 999);
        await base44.asServiceRole.entities.Resource.update(res.id, { quantity: newQty });
        resourceResults.push({ resource: drop.type, label: drop.label, rarity: drop.rarity, gained: 1 });
      }

      const updatedSkill = await base44.asServiceRole.entities.LifeSkill.update(skill.id, {
        level: currentLevel,
        exp: Math.floor(currentExp),
        exp_to_next: currentExpToNext,
        gather_progress: Math.min(totalProgress, 99.9),
        last_tick_at: new Date().toISOString(),
      });

      return Response.json({
        success: true, resources: resourceResults,
        xp_gained: totalXpGained, leveled_up: leveledUp,
        new_level: currentLevel,
        skill: enrichSkill(updatedSkill, skill_type),
      });
    }

    // ─── UPGRADE ──────────────────────────────────────────────────────────────
    if (action === 'upgrade') {
      const { upgrade_type } = body;
      if (!skill_type || !upgrade_type) return Response.json({ error: 'skill_type and upgrade_type required' }, { status: 400 });

      const skill = await getOrCreateSkill(base44, character_id, skill_type);
      const MAX = 10;

      if (upgrade_type === 'speed') {
        const lvl = skill.speed_level || 1;
        if (lvl >= MAX) return Response.json({ error: 'Max level' }, { status: 400 });
        const cost = speedUpgradeCost(lvl);
        if ((character.gold || 0) < cost) return Response.json({ error: `Need ${cost} gold` }, { status: 400 });
        await base44.asServiceRole.entities.Character.update(character_id, { gold: character.gold - cost });
        const updated = await base44.asServiceRole.entities.LifeSkill.update(skill.id, { speed_level: lvl + 1 });
        return Response.json({ success: true, gold_spent: cost, new_speed_level: lvl + 1, skill: enrichSkill(updated, skill_type) });
      }

      if (upgrade_type === 'luck') {
        const lvl = skill.luck_level || 1;
        if (lvl >= MAX) return Response.json({ error: 'Max level' }, { status: 400 });
        const cost = luckUpgradeCost(lvl);
        if ((character.gold || 0) < cost) return Response.json({ error: `Need ${cost} gold` }, { status: 400 });
        await base44.asServiceRole.entities.Character.update(character_id, { gold: character.gold - cost });
        const updated = await base44.asServiceRole.entities.LifeSkill.update(skill.id, { luck_level: lvl + 1 });
        return Response.json({ success: true, gold_spent: cost, new_luck_level: lvl + 1, skill: enrichSkill(updated, skill_type) });
      }

      return Response.json({ error: 'Unknown upgrade_type' }, { status: 400 });
    }

    // ─── PROCESS (smelting / cooking / alchemy) ───────────────────────────────
    // Consumes N input resources and produces N output resources of same rarity
    if (action === 'process') {
      const { process_type, recipe_input, quantity } = body;
      if (!process_type || !recipe_input) return Response.json({ error: 'process_type and recipe_input required' }, { status: 400 });

      const proc = PROCESSING_RECIPES[process_type];
      if (!proc) return Response.json({ error: 'Unknown process_type' }, { status: 400 });

      // Check unlock
      const baseSkill = await getOrCreateSkill(base44, character_id, proc.requires_skill);
      if ((baseSkill.level || 1) < proc.requires_level) {
        return Response.json({ error: `Requires ${proc.requires_skill} level ${proc.requires_level}` }, { status: 403 });
      }

      const recipe = proc.recipes.find(r => r.input === recipe_input);
      if (!recipe) return Response.json({ error: 'Unknown recipe' }, { status: 400 });

      const qty = Math.max(1, Math.min(parseInt(quantity) || 1, 999));

      // Find input resource stack
      const inputStacks = await base44.asServiceRole.entities.Resource.filter({
        character_id, resource_type: recipe.input, rarity: recipe.rarity,
      });
      const inputStack = inputStacks[0];
      if (!inputStack || (inputStack.quantity || 0) < qty) {
        return Response.json({ error: `Not enough ${recipe.input_label} (need ${qty})` }, { status: 400 });
      }

      // Deduct input
      await base44.asServiceRole.entities.Resource.update(inputStack.id, {
        quantity: inputStack.quantity - qty,
      });

      // Add output
      const outputStack = await getOrCreateResource(base44, character_id, recipe.output, recipe.rarity);
      const newOutQty = Math.min((outputStack.quantity || 0) + qty, 999);
      await base44.asServiceRole.entities.Resource.update(outputStack.id, { quantity: newOutQty });

      return Response.json({
        success: true,
        consumed: { resource: recipe.input, label: recipe.input_label, qty },
        produced: { resource: recipe.output, label: recipe.output_label, qty },
        rarity: recipe.rarity,
      });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    console.error('lifeSkills error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});